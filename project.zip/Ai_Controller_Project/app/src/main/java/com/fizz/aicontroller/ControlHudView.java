package com.fizz.aicontroller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Non-touchable overlay showing saved control centers. */
final class ControlHudView extends View {
    private final String[] controls = {"move", "jump", "sprint", "crouch", "prone", "interact", "heal", "gloo", "camera"};
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] colors = {0xFF39D8C0, 0xFF4D9BE8, 0xFFF0B75E, 0xFFB68AE5, 0xFFE18AA7, 0xFF65B8D0, 0xFF7AC58C, 0xFF2687C7, 0xFFB98CF3};
    private boolean visible = true;

    ControlHudView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    void setVisible(boolean v) { visible = v; invalidate(); }
    boolean isVisible() { return visible; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!visible) return;
        float density = getResources().getDisplayMetrics().density;
        float hpX1 = getWidth() * BotSettings.xPercent(getContext(), "hp_start") / 100f;
        float hpY1 = getHeight() * BotSettings.yPercent(getContext(), "hp_start") / 100f;
        float hpX2 = getWidth() * BotSettings.xPercent(getContext(), "hp_end") / 100f;
        float hpY2 = getHeight() * BotSettings.yPercent(getContext(), "hp_end") / 100f;
        p.setColor(0xFF63D8F2); p.setStyle(Paint.Style.FILL);
        canvas.drawCircle(hpX1, hpY1, 5f * density, p);
        canvas.drawCircle(hpX2, hpY2, 5f * density, p);
        for (int i = 0; i < controls.length; i++) {
            String id = controls[i];
            float x = getWidth() * BotSettings.xPercent(getContext(), id) / 100f;
            float y = getHeight() * BotSettings.yPercent(getContext(), id) / 100f;
            float r = (id.equals("move") ? 38f : 25f) * density;
            p.setStyle(Paint.Style.FILL); p.setColor((colors[i] & 0x00FFFFFF) | 0x30000000); canvas.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f * density); p.setColor(colors[i]);
            canvas.drawCircle(x, y, r, p); canvas.drawCircle(x, y, 4f*density, p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(12f*density); p.setFakeBoldText(true);
            p.setColor(0xFFFFFFFF); canvas.drawText(String.valueOf(i + 1), x, y + 4f*density, p);
        }
        p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(10f*density); p.setColor(0xFF63D8F2);
        canvas.drawText("HP", (hpX1 + hpX2) / 2f, (hpY1 + hpY2) / 2f - 7f*density, p);
    }
}
