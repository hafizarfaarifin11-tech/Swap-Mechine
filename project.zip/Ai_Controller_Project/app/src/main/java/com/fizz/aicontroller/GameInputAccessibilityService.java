package com.fizz.aicontroller;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class GameInputAccessibilityService extends AccessibilityService {
    private static volatile GameInputAccessibilityService instance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean gestureBusy;

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { gestureBusy = false; }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static boolean isReady() { return instance != null; }
    public static boolean isBusy() { return instance != null && instance.gestureBusy; }

    public static void tap(int x, int y, long durationMs) {
        GameInputAccessibilityService service = instance;
        if (service == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        service.runGesture(() -> {
            Path path = new Path(); path.moveTo(x, y);
            return new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(path, 0, Math.max(45, durationMs))).build();
        });
    }

    public static void swipe(int startX, int startY, int endX, int endY, long durationMs) {
        GameInputAccessibilityService service = instance;
        if (service == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        service.runGesture(() -> {
            Path path = new Path(); path.moveTo(startX, startY); path.lineTo(endX, endY);
            return new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(path, 0, Math.max(90, durationMs))).build();
        });
    }

    private interface GestureFactory { GestureDescription create(); }
    private void runGesture(GestureFactory factory) {
        mainHandler.post(() -> {
            if (gestureBusy || instance != this) return;
            gestureBusy = true;
            boolean accepted = dispatchGesture(factory.create(), new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gesture) { gestureBusy = false; }
                @Override public void onCancelled(GestureDescription gesture) { gestureBusy = false; }
            }, mainHandler);
            if (!accepted) gestureBusy = false;
        });
    }
}
