package com.fizz.aicontroller;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class GameInputAccessibilityService extends AccessibilityService {
    private static volatile GameInputAccessibilityService instance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean gestureBusy;
    private volatile String foregroundPackage = "";

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || event.getPackageName() == null) return;
        String packageName = event.getPackageName().toString();
        // Ignore our own overlay package. Opening or minimizing the AI bubble is UI-only
        // and must not replace the actual game package tracked by this service.
        if (!packageName.equals(getPackageName())) foregroundPackage = packageName;
    }
    @Override public void onInterrupt() { gestureBusy = false; }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static boolean isReady() { return instance != null; }
    public static boolean isBusy() { return instance != null && instance.gestureBusy; }
    public static String getForegroundPackage() {
        GameInputAccessibilityService service = instance;
        return service == null ? "" : service.foregroundPackage;
    }

    public static boolean isPackageVisible(String packageName) {
        GameInputAccessibilityService service = instance;
        if (service == null || packageName == null || packageName.isEmpty()) return false;
        String current = service.foregroundPackage;
        return packageName.equals(current)
                && !service.getPackageName().equals(current)
                && !isSystemOrLauncherPackage(current);
    }

    public static boolean isExternalAppVisible() {
        GameInputAccessibilityService service = instance;
        return service != null && !service.foregroundPackage.isEmpty()
                && !service.getPackageName().equals(service.foregroundPackage)
                && !isSystemOrLauncherPackage(service.foregroundPackage);
    }

    public static boolean isSystemOrLauncherPackage(String packageName) {
        if (packageName == null) return true;
        String value = packageName.toLowerCase(java.util.Locale.ROOT);
        return value.equals("android") || value.equals("com.android.systemui")
                || value.contains("launcher") || value.contains("permissioncontroller")
                || value.equals("com.android.settings");
    }

    public static void tap(int x, int y, long durationMs) {
        GameInputAccessibilityService service = instance;
        if (service == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        service.runGesture(() -> {
            Path path = new Path(); path.moveTo(x, y);
            return new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(path, 0, Math.max(45, durationMs))).build();
        });
    }

    public static void tapControl(android.content.Context context, String control) {
        tap(BotSettings.px(context, control, true), BotSettings.px(context, control, false), 80);
    }

    public static void holdControl(android.content.Context context, String control, long durationMs) {
        tap(BotSettings.px(context, control, true), BotSettings.px(context, control, false), Math.max(250, Math.min(1500, durationMs)));
    }

    public static void swipe(int startX, int startY, int endX, int endY, long durationMs) {
        GameInputAccessibilityService service = instance;
        if (service == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        service.runGesture(() -> {
            Path path = new Path(); path.moveTo(startX, startY); path.lineTo(endX, endY);
            return new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(path, 0, Math.max(90, Math.min(5000, durationMs)))).build();
        });
    }

    /**
     * Presses the joystick pad, drags it to the requested vector, then keeps
     * the virtual finger down through continued accessibility gestures. This
     * avoids the short tap/release behavior that many games ignore.
     */
    public static void moveJoystick(android.content.Context context, float dx, float dy, long holdMs) {
        GameInputAccessibilityService service = instance;
        if (service == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        int sx = BotSettings.px(context, "move", true);
        int sy = BotSettings.px(context, "move", false);
        android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
        android.view.WindowManager wm = (android.view.WindowManager) context.getSystemService(android.content.Context.WINDOW_SERVICE);
        if (wm != null) wm.getDefaultDisplay().getRealMetrics(metrics);
        float radius = Math.max(28f, Math.min(metrics.widthPixels, metrics.heightPixels) * 0.105f);
        int ex = Math.max(2, Math.min(metrics.widthPixels - 3, Math.round(sx + Math.max(-1f, Math.min(1f, dx)) * radius)));
        int ey = Math.max(2, Math.min(metrics.heightPixels - 3, Math.round(sy + Math.max(-1f, Math.min(1f, dy)) * radius)));
        service.startJoystickStroke(sx, sy, ex, ey, Math.max(500, Math.min(4000, holdMs)));
    }

    /** Drag the camera from its calibrated anchor; dx/dy are fractions of the display. */
    public static void panCamera(android.content.Context context, float dx, float dy, long durationMs) {
        int sx = BotSettings.px(context, "camera", true);
        int sy = BotSettings.px(context, "camera", false);
        android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
        android.view.WindowManager wm = (android.view.WindowManager) context.getSystemService(android.content.Context.WINDOW_SERVICE);
        if (wm != null) wm.getDefaultDisplay().getRealMetrics(metrics);
        int ex = Math.max(2, Math.min(metrics.widthPixels - 3, Math.round(sx + dx * metrics.widthPixels)));
        int ey = Math.max(2, Math.min(metrics.heightPixels - 3, Math.round(sy + dy * metrics.heightPixels)));
        swipe(sx, sy, ex, ey, durationMs);
    }

    private void startJoystickStroke(int sx, int sy, int ex, int ey, long holdMs) {
        mainHandler.post(() -> {
            if (gestureBusy || instance != this) return;
            gestureBusy = true;
            Path path = new Path(); path.moveTo(sx, sy); path.lineTo(ex, ey);
            GestureDescription.StrokeDescription first = new GestureDescription.StrokeDescription(path, 0, 150, true);
            boolean accepted = dispatchGesture(new GestureDescription.Builder().addStroke(first).build(),
                    new GestureResultCallback() {
                        @Override public void onCompleted(GestureDescription gesture) {
                            continueJoystick(first, ex, ey, holdMs);
                        }
                        @Override public void onCancelled(GestureDescription gesture) { gestureBusy = false; }
                    }, mainHandler);
            if (!accepted) gestureBusy = false;
        });
    }

    private void continueJoystick(GestureDescription.StrokeDescription previous, float x, float y, long remainingMs) {
        long chunk = Math.min(500, Math.max(120, remainingMs));
        boolean more = remainingMs > chunk;
        Path holdPath = new Path();
        holdPath.moveTo(x, y);
        holdPath.lineTo(x + 1f, y);
        final GestureDescription.StrokeDescription next;
        try { next = previous.continueStroke(holdPath, 0, chunk, more); }
        catch (Exception e) { gestureBusy = false; return; }
        boolean accepted = dispatchGesture(new GestureDescription.Builder().addStroke(next).build(),
                new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gesture) {
                        if (more) continueJoystick(next, x + 1f, y, remainingMs - chunk);
                        else gestureBusy = false;
                    }
                    @Override public void onCancelled(GestureDescription gesture) { gestureBusy = false; }
                }, mainHandler);
        if (!accepted) gestureBusy = false;
    }

    private interface GestureFactory { GestureDescription create(); }
    private void runGesture(GestureFactory factory) {
        mainHandler.post(() -> {
            if (gestureBusy || instance != this) return;
            gestureBusy = true;
            boolean accepted = dispatchGesture(factory.create(), new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gesture) { gestureBusy = false; }
                @Override public void onCancelled(GestureDescription gesture) { gestureBusy = false; }
            }, mainHandler);
            if (!accepted) gestureBusy = false;
        });
    }
}
