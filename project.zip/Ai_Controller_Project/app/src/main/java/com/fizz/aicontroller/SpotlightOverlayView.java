package com.fizz.aicontroller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.PorterDuffXfermode;
import android.view.MotionEvent;
import android.view.View;

/**
 * Full-screen dim layer with a transparent circular spotlight.
 * It does not capture the underlying app or inspect game pixels.
 */
public class SpotlightOverlayView extends View {
    public interface Callback {
        void onPositionSaved(float xFraction, float yFraction);
        void onDismiss();
    }

    private final Callback callback;
    private final Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint buttonPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint buttonTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF saveButton = new RectF();

    private float xFraction;
    private float yFraction;
    private float centerX;
    private float centerY;
    private float radius;
    private boolean calibration;
    private boolean positionInitialized;
    private boolean dragging;
    private boolean downOnSave;
    private boolean pendingTap;
    private float downX;
    private float downY;
    private float dragOffsetX;
    private float dragOffsetY;
    private final float density;

    public SpotlightOverlayView(Context context, float xFraction, float yFraction,
                                boolean calibration, Callback callback) {
        super(context);
        this.xFraction = clampFraction(xFraction);
        this.yFraction = clampFraction(yFraction);
        this.calibration = calibration;
        this.callback = callback;
        this.density = getResources().getDisplayMetrics().density;
        this.radius = dp(51);

        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeCap(Paint.Cap.ROUND);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(dp(13));
        textPaint.setTypeface(android.graphics.Typeface.create(
                "sans-serif-medium", android.graphics.Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.CENTER);
        buttonPaint.setColor(0xFF36D6B0);
        buttonTextPaint.setColor(0xFF06130F);
        buttonTextPaint.setTextSize(dp(13));
        buttonTextPaint.setTypeface(android.graphics.Typeface.create(
                "sans-serif", android.graphics.Typeface.BOLD));
        buttonTextPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setColor(0xFFFFFFFF);
        labelPaint.setTextSize(dp(11));
        labelPaint.setTypeface(android.graphics.Typeface.create(
                "sans-serif", android.graphics.Typeface.BOLD));
        labelPaint.setTextAlign(Paint.Align.CENTER);
        setClickable(true);
    }

    public void setCalibration(boolean enabled) {
        calibration = enabled;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!positionInitialized && w > 0 && h > 0) {
            centerX = w * xFraction;
            centerY = h * yFraction;
            clampCenter();
            positionInitialized = true;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (!positionInitialized) {
            centerX = w * xFraction;
            centerY = h * yFraction;
            clampCenter();
            positionInitialized = true;
        }

        int layer = canvas.saveLayer(0, 0, w, h, null);
        canvas.drawColor(0xD9000000);
        canvas.drawCircle(centerX, centerY, radius, clearPaint);
        canvas.restoreToCount(layer);

        // Three strokes create a visible neon glow without animating or processing frames.
        ringPaint.setColor(0x5536D6B0);
        ringPaint.setStrokeWidth(dp(17));
        canvas.drawCircle(centerX, centerY, radius, ringPaint);
        ringPaint.setColor(0xAA36D6B0);
        ringPaint.setStrokeWidth(dp(8));
        canvas.drawCircle(centerX, centerY, radius, ringPaint);
        ringPaint.setColor(0xFFB8FFF0);
        ringPaint.setStrokeWidth(dp(2));
        canvas.drawCircle(centerX, centerY, radius, ringPaint);

        String label = calibration ? "POSISI TOMBOL LONCAT" : "TOMBOL LONCAT ADA DI SINI";
        float labelY = centerY - radius - dp(16);
        if (labelY < dp(64)) labelY = centerY + radius + dp(25);
        canvas.drawText(label, centerX, labelY, labelPaint);

        drawTopInstruction(canvas, w);
        if (calibration) {
            float bw = Math.min(w - dp(36), dp(230));
            float bh = dp(52);
            float left = (w - bw) / 2f;
            float top = dp(82);
            saveButton.set(left, top, left + bw, top + bh);
            canvas.drawRoundRect(saveButton, dp(15), dp(15), buttonPaint);
            canvas.drawText("SIMPAN POSISI", saveButton.centerX(),
                    saveButton.centerY() + dp(4.5f), buttonTextPaint);
        } else {
            saveButton.setEmpty();
            textPaint.setAlpha(235);
            canvas.drawText("KETUK LAYAR UNTUK MENUTUP", w / 2f,
                    h - dp(48), textPaint);
            textPaint.setAlpha(255);
        }
    }

    private void drawTopInstruction(Canvas canvas, float width) {
        String line = calibration
                ? "Ketuk atau geser lingkaran ke tombol game"
                : "Area lain diredupkan agar tombol mudah ditemukan";
        textPaint.setTextSize(dp(12));
        float y = dp(38);
        canvas.drawText("BHOP PRO COACH", width / 2f, y, textPaint);
        textPaint.setTextSize(dp(10));
        textPaint.setColor(0xFFD6E4E8);
        canvas.drawText(line, width / 2f, y + dp(22), textPaint);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(dp(13));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!calibration) {
                    return true;
                }
                downX = x;
                downY = y;
                downOnSave = saveButton.contains(x, y);
                pendingTap = !downOnSave;
                dragging = false;
                if (distance(x, y, centerX, centerY) <= radius + dp(42)) {
                    dragging = true;
                    pendingTap = false;
                    dragOffsetX = centerX - x;
                    dragOffsetY = centerY - y;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!calibration) return true;
                if (downOnSave) return true;
                float movedX = x - downX;
                float movedY = y - downY;
                if (pendingTap && Math.hypot(movedX, movedY) > dp(8)) {
                    dragging = true;
                    pendingTap = false;
                    dragOffsetX = 0;
                    dragOffsetY = 0;
                }
                if (dragging) {
                    centerX = x + dragOffsetX;
                    centerY = y + dragOffsetY;
                    clampCenter();
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
                if (!calibration) {
                    if (callback != null) callback.onDismiss();
                    return true;
                }
                if (downOnSave && saveButton.contains(x, y)) {
                    xFraction = getWidth() == 0 ? 0.82f : centerX / getWidth();
                    yFraction = getHeight() == 0 ? 0.76f : centerY / getHeight();
                    if (callback != null) callback.onPositionSaved(
                            clampFraction(xFraction), clampFraction(yFraction));
                } else if (pendingTap && !dragging) {
                    centerX = x;
                    centerY = y;
                    clampCenter();
                    invalidate();
                }
                downOnSave = false;
                pendingTap = false;
                dragging = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                downOnSave = false;
                pendingTap = false;
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    private void clampCenter() {
        float w = Math.max(getWidth(), dp(120));
        float h = Math.max(getHeight(), dp(180));
        centerX = Math.max(radius + dp(10), Math.min(w - radius - dp(10), centerX));
        centerY = Math.max(radius + dp(145), Math.min(h - radius - dp(22), centerY));
    }

    private float distance(float x1, float y1, float x2, float y2) {
        return (float) Math.hypot(x1 - x2, y1 - y2);
    }

    private float clampFraction(float value) {
        return Math.max(0.08f, Math.min(0.92f, value));
    }

    private float dp(float value) {
        return value * density;
    }
}
