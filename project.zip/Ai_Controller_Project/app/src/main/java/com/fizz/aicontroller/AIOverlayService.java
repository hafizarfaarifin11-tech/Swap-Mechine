package com.fizz.aicontroller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class AIOverlayService extends Service {
    private static final String CHANNEL_ID = "bhop_coach_overlay";
    private static final int NOTIFICATION_ID = 7302;
    private static final String ACTION_STOP = "com.fizz.aicontroller.STOP_COACH";

    private WindowManager windowManager;
    private WindowManager.LayoutParams overlayParams;
    private View currentOverlay;
    private TextView adviceView;
    private TextView statusView;
    private boolean expanded = false;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            showToast("Izin overlay belum aktif");
            stopSelf();
            return START_NOT_STICKY;
        }

        startAsForegroundService();
        if (currentOverlay == null) {
            showBubble();
        }
        return START_NOT_STICKY;
    }

    private void startAsForegroundService() {
        Intent stopIntent = new Intent(this, AIOverlayService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPendingIntent = PendingIntent.getActivity(
                this, 3, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Bhop Pro Coach aktif")
                .setContentText("Tips offline aktif • tidak membaca layar")
                .setContentIntent(openPendingIntent)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_launcher),
                        "Hentikan", stopPendingIntent).build());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    private void showBubble() {
        if (currentOverlay != null) {
            try {
                windowManager.removeView(currentOverlay);
            } catch (Exception ignored) {
            }
            currentOverlay = null;
        }

        TextView bubble = new TextView(this);
        bubble.setText("B");
        bubble.setTextSize(22);
        bubble.setTextColor(0xFF06130F);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubble.setElevation(dp(7));
        bubble.setBackground(background(0xFF36D6B0, dp(32)));

        overlayParams = new WindowManager.LayoutParams(
                dp(62), dp(62),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = dp(12);
        overlayParams.y = dp(180);
        currentOverlay = bubble;
        attachDrag(bubble, this::expandPanel);

        try {
            windowManager.addView(currentOverlay, overlayParams);
            expanded = false;
        } catch (Exception exception) {
            currentOverlay = null;
            showToast("Bubble gagal ditampilkan. Periksa izin overlay.");
            stopSelf();
        }
    }

    private void expandPanel() {
        if (expanded || currentOverlay == null) return;
        View panel = makePanel();
        replaceOverlay(panel, panelWidth(), panelHeight());
        expanded = true;
    }

    private View makePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(13), dp(12), dp(13), dp(13));
        panel.setBackground(background(0xF0161F2A, dp(18)));
        panel.setElevation(dp(9));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView heading = new TextView(this);
        heading.setText("BHOP PRO COACH");
        heading.setTextColor(0xFF36D6B0);
        heading.setTextSize(12);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setLetterSpacing(0.06f);
        header.addView(heading, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView close = smallAction("×", 23, 0xFFFFFFFF);
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> collapsePanel());
        attachDrag(header, null);
        panel.addView(header);

        statusView = new TextView(this);
        statusView.setText("Pilih kondisi permainan. Saran dibuat offline dan manual.");
        statusView.setTextColor(0xFFB7C2CC);
        statusView.setTextSize(11);
        statusView.setPadding(0, dp(3), 0, dp(9));
        panel.addView(statusView);

        TextView resultLabel = new TextView(this);
        resultLabel.setText("SARAN LATIHAN");
        resultLabel.setTextColor(0xFF36D6B0);
        resultLabel.setTextSize(10);
        resultLabel.setTypeface(Typeface.DEFAULT_BOLD);
        resultLabel.setPadding(0, dp(3), 0, dp(6));
        panel.addView(resultLabel);

        adviceView = new TextView(this);
        adviceView.setText("Belum ada situasi dipilih. Ketuk salah satu kondisi di bawah untuk mendapatkan arahan Bhop Pro.");
        adviceView.setTextColor(0xFFFFFFFF);
        adviceView.setTextSize(12);
        adviceView.setLineSpacing(dp(3), 1.0f);
        adviceView.setPadding(dp(11), dp(10), dp(11), dp(10));
        adviceView.setBackground(background(0xFF202B38, dp(12)));
        panel.addView(adviceView, new LinearLayout.LayoutParams(-1, -2));

        TextView chooseLabel = new TextView(this);
        chooseLabel.setText("PILIH KONDISI KAMU");
        chooseLabel.setTextColor(0xFFB7C2CC);
        chooseLabel.setTextSize(10);
        chooseLabel.setTypeface(Typeface.DEFAULT_BOLD);
        chooseLabel.setPadding(0, dp(12), 0, dp(5));
        panel.addView(chooseLabel);

        ScrollView choicesScroll = new ScrollView(this);
        choicesScroll.setFillViewport(false);
        LinearLayout choices = new LinearLayout(this);
        choices.setOrientation(LinearLayout.VERTICAL);
        choices.addView(makeChoice("Dasar bunny hop", 0));
        choices.addView(makeChoice("Speed tidak naik", 1));
        choices.addView(makeChoice("Latihan belok kiri", 2));
        choices.addView(makeChoice("Latihan belok kanan", 3));
        choices.addView(makeChoice("Sering kehilangan kontrol", 4));
        choices.addView(makeChoice("Menjelang mendarat", 5));
        choices.addView(makeChoice("Atur kontrol sentuh", 6));
        choices.addView(makeChoice("Rencana latihan singkat", 7));
        choicesScroll.addView(choices);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrollParams.topMargin = dp(2);
        panel.addView(choicesScroll, scrollParams);

        TextView footnote = new TextView(this);
        footnote.setText("Tidak membaca layar • Tidak merekam • Tidak menekan tombol game");
        footnote.setTextColor(0xFF8392A1);
        footnote.setTextSize(9);
        footnote.setGravity(Gravity.CENTER);
        footnote.setPadding(0, dp(8), 0, 0);
        panel.addView(footnote);

        return panel;
    }

    private Button makeChoice(String label, int scenario) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(12);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(0xFFEAF2F6);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(12), 0, dp(12), 0);
        button.setMinHeight(dp(44));
        button.setBackground(background(0xFF263441, dp(10)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(44));
        params.topMargin = dp(5);
        button.setLayoutParams(params);
        button.setOnClickListener(v -> showAdvice(scenario));
        return button;
    }

    private void showAdvice(int scenario) {
        String title;
        String advice;
        switch (scenario) {
            case 0:
                title = "Dasar bunny hop";
                advice = "1. Mulai dari map yang sudah kamu kenal atau yang lebih mudah.\n\n"
                        + "2. Di mode FPS, sinkronkan input lompat dengan gerakan putar kiri atau kanan.\n\n"
                        + "3. Buat gerakan putar terkontrol. Utamakan ritme dan kontrol sebelum mengejar kecepatan.";
                break;
            case 1:
                title = "Speed tidak naik";
                advice = "Coba periksa sinkronisasi antara lompatan dan air-strafing. Deskripsi Bhop Pro menjelaskan bahwa bunny hop memakai gerakan putar kiri/kanan yang dilakukan selaras dengan lompatan.\n\n"
                        + "Kurangi swipe yang terlalu mendadak. Ulangi lintasan yang sama dan ubah satu hal saja setiap percobaan agar mudah membandingkan hasil.";
                break;
            case 2:
                title = "Latihan belok kiri";
                advice = "Saat karakter melayang, coba arahkan putaran ke kiri secara bertahap sambil memberi input gerak yang sesuai. Selaraskan ritme putaran dengan tombol lompat.\n\n"
                        + "Mulai dengan gerakan kecil dan stabil. Jangan langsung menggeser pandangan terlalu jauh.";
                break;
            case 3:
                title = "Latihan belok kanan";
                advice = "Saat karakter melayang, coba arahkan putaran ke kanan secara bertahap sambil memberi input gerak yang sesuai. Selaraskan ritme putaran dengan tombol lompat.\n\n"
                        + "Mulai dengan gerakan kecil dan stabil. Jangan langsung menggeser pandangan terlalu jauh.";
                break;
            case 4:
                title = "Sering kehilangan kontrol";
                advice = "Turunkan dulu intensitas belokan. Fokus pada satu rangkaian gerak yang konsisten, bukan kecepatan tertinggi.\n\n"
                        + "Pilih map yang lebih mudah atau sudah dikenal. Setelah lebih stabil, tingkatkan gerakan sedikit demi sedikit.";
                break;
            case 5:
                title = "Menjelang mendarat";
                advice = "Sebelum mendarat, perhatikan area platform yang ingin dituju. Hindari koreksi arah yang terlalu besar pada saat terakhir.\n\n"
                        + "Latih pendekatan yang stabil dahulu. Jika sering melewati platform, kurangi besar gerakan putar pada percobaan berikutnya.";
                break;
            case 6:
                title = "Atur kontrol sentuh";
                advice = "Pastikan tombol lompat, gerak, dan area untuk memutar pandangan nyaman dijangkau tanpa menutup pandangan utama.\n\n"
                        + "Jika ingin mengubah sensitivitas, ubah sedikit demi sedikit dan uji pada lintasan yang sama. Hindari mengubah banyak pengaturan sekaligus.";
                break;
            default:
                title = "Rencana latihan singkat";
                advice = "LATIHAN 1 — Pilih satu map yang sudah dikenal. Fokuskan beberapa percobaan pada sinkronisasi lompat dan putaran.\n\n"
                        + "LATIHAN 2 — Ulangi lintasan yang sama dengan gerakan putar lebih halus.\n\n"
                        + "LATIHAN 3 — Bandingkan hasilnya. Pertahankan perubahan yang membuat gerakan lebih stabil.";
                break;
        }
        if (adviceView != null) {
            adviceView.setText(title + "\n\n" + advice);
        }
        if (statusView != null) {
            statusView.setText("Profil: Bhop Pro • Saran offline berdasarkan pilihanmu");
        }
    }

    private void collapsePanel() {
        if (!expanded) return;
        showBubble();
    }

    private void replaceOverlay(View newView, int width, int height) {
        try {
            if (currentOverlay != null) {
                windowManager.removeView(currentOverlay);
            }
            currentOverlay = newView;
            overlayParams.width = width;
            overlayParams.height = height;
            clampOverlayPosition();
            windowManager.addView(currentOverlay, overlayParams);
        } catch (Exception exception) {
            currentOverlay = null;
            expanded = false;
            showToast("Panel overlay gagal dibuka");
            stopSelf();
        }
    }

    private void attachDrag(View touchTarget, Runnable onTap) {
        final float[] down = new float[2];
        final int[] start = new int[2];
        final boolean[] moved = new boolean[1];

        touchTarget.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = event.getRawX();
                    down[1] = event.getRawY();
                    start[0] = overlayParams.x;
                    start[1] = overlayParams.y;
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - down[0];
                    float dy = event.getRawY() - down[1];
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) {
                        moved[0] = true;
                    }
                    if (moved[0] && currentOverlay != null) {
                        overlayParams.x = start[0] + Math.round(dx);
                        overlayParams.y = start[1] + Math.round(dy);
                        clampOverlayPosition();
                        try {
                            windowManager.updateViewLayout(currentOverlay, overlayParams);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0] && onTap != null) onTap.run();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
                default:
                    return false;
            }
        });
    }

    private void clampOverlayPosition() {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        overlayParams.x = Math.max(0, Math.min(overlayParams.x, screenWidth - overlayParams.width));
        overlayParams.y = Math.max(0, Math.min(overlayParams.y, screenHeight - overlayParams.height));
    }

    private int panelWidth() {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        return Math.max(dp(250), Math.min(dp(322), screenWidth - dp(24)));
    }

    private int panelHeight() {
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        return Math.max(dp(360), Math.min(dp(540), screenHeight - dp(70)));
    }

    private TextView smallAction(String label, int size, int color) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        view.setBackground(background(0xFF263441, dp(10)));
        return view;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Bhop Pro Coach", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Notifikasi saat floating Bhop Pro Coach aktif");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (currentOverlay != null) {
            try {
                windowManager.removeView(currentOverlay);
            } catch (Exception ignored) {
            }
            currentOverlay = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
