package com.fizz.aicontroller;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.util.DisplayMetrics;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Drag-and-drop editor. Coordinates are saved as display percentages. */
public class ControlLayoutActivity extends Activity {
    private FrameLayout canvas;
    private final String[] ids = {"move", "jump", "sprint", "crouch", "prone", "interact", "heal", "gloo", "camera", "hp_start", "hp_end"};
    private final String[] labels = {"JOYSTICK", "LOMPAT", "LARI", "JONGKOK", "TIARAP", "INTERAKSI", "HEAL", "GLOO WALL", "KAMERA", "HP AWAL", "HP AKHIR"};
    private final int[] colors = {0xFF1C9C88, 0xFF2E8BDA, 0xFFE2A2A2, 0xFFBD8D35, 0xFF875BC0, 0xFF4D8E9C, 0xFF4D9860, 0xFF2687C7, 0xFF8C63C7, 0xFFCA4D59, 0xFFCA4D59};
    private final TextView[] handles = new TextView[11];

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        buildEditor();
    }

    private void buildEditor() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF09111B);
        canvas = new FrameLayout(this);
        // GridBackground is a View, not a Drawable: add it as the first child
        // so draggable control handles are drawn above the grid.
        canvas.addView(new GridBackground(this), new FrameLayout.LayoutParams(-1, -1));
        root.addView(canvas, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setPadding(dp(12), dp(8), dp(12), dp(8));
        toolbar.setBackground(shape(0xE8172432, dp(14)));
        TextView title = new TextView(this);
        title.setText("CONTROL LAYOUT EDITOR"); title.setTextColor(0xFF52E0C4);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setTextSize(14);
        toolbar.addView(title);
        TextView help = new TextView(this);
        help.setText("Geser label ke tengah tombol game. Untuk posisi paling akurat, gunakan EDIT LAYOUT DI GAME dari bubble AI; HP AWAL dan HP AKHIR menandai ujung bar darah.");
        help.setTextColor(0xFFD5DEE8); help.setTextSize(10);
        toolbar.addView(help);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button save = actionButton("SIMPAN");
        Button reset = actionButton("RESET");
        Button done = actionButton("SELESAI");
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(42), 1));
        actions.addView(reset, new LinearLayout.LayoutParams(0, dp(42), 1));
        actions.addView(done, new LinearLayout.LayoutParams(0, dp(42), 1));
        toolbar.addView(actions);
        FrameLayout.LayoutParams bar = new FrameLayout.LayoutParams(dp(350), -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        bar.topMargin = dp(8);
        root.addView(toolbar, bar);
        save.setOnClickListener(v -> saveLayout());
        reset.setOnClickListener(v -> { resetDefaults(); Toast.makeText(this, "Posisi default dipulihkan", Toast.LENGTH_SHORT).show(); });
        done.setOnClickListener(v -> { saveLayout(); finish(); });
        setContentView(root);
        root.post(this::createHandles);
    }

    private void createHandles() {
        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            TextView handle = new TextView(this);
            handle.setText(labels[i]); handle.setTextColor(Color.WHITE); handle.setTextSize(10);
            handle.setTypeface(Typeface.DEFAULT, Typeface.BOLD); handle.setGravity(Gravity.CENTER);
            handle.setPadding(dp(9), dp(7), dp(9), dp(7)); handle.setElevation(dp(8));
            handle.setBackground(shape(colors[i], dp(18)));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(i == 0 ? 94 : 82), dp(46));
            canvas.addView(handle, lp);
            handles[i] = handle;
            float x = BotSettings.xPercent(this, ids[i]) / 100f;
            float y = BotSettings.yPercent(this, ids[i]) / 100f;
            handle.post(() -> {
                DisplayMetrics dm = screenMetrics();
                int[] canvasLocation = new int[2]; canvas.getLocationOnScreen(canvasLocation);
                float centerScreenX = x * (dm.widthPixels - 1);
                float centerScreenY = y * (dm.heightPixels - 1);
                float left = clamp(centerScreenX - canvasLocation[0] - handle.getWidth() / 2f, 0, canvas.getWidth() - handle.getWidth());
                float top = clamp(centerScreenY - canvasLocation[1] - handle.getHeight() / 2f, 0, canvas.getHeight() - handle.getHeight());
                handle.setX(left); handle.setY(top);
            });
            handle.setOnTouchListener(new View.OnTouchListener() {
                float downRawX, downRawY, startX, startY;
                @Override public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            downRawX = event.getRawX(); downRawY = event.getRawY();
                            startX = v.getX(); startY = v.getY(); return true;
                        case MotionEvent.ACTION_MOVE:
                            float nx = startX + event.getRawX() - downRawX;
                            float ny = startY + event.getRawY() - downRawY;
                            v.setX(clamp(nx, 0, canvas.getWidth() - v.getWidth()));
                            v.setY(clamp(ny, 0, canvas.getHeight() - v.getHeight())); return true;
                        case MotionEvent.ACTION_UP:
                            saveOne(index); v.performClick(); return true;
                        default: return true;
                    }
                }
            });
        }
    }

    private void saveOne(int index) {
        if (canvas.getWidth() <= 0 || canvas.getHeight() <= 0 || handles[index] == null) return;
        View v = handles[index];
        int[] canvasLocation = new int[2]; canvas.getLocationOnScreen(canvasLocation);
        DisplayMetrics dm = screenMetrics();
        float screenX = canvasLocation[0] + v.getX() + v.getWidth() / 2f;
        float screenY = canvasLocation[1] + v.getY() + v.getHeight() / 2f;
        float x = screenX / Math.max(1f, dm.widthPixels - 1) * 100f;
        float y = screenY / Math.max(1f, dm.heightPixels - 1) * 100f;
        BotSettings.prefs(this).edit().putFloat("map_" + ids[index] + "_x", clamp(x, 0f, 100f))
                .putFloat("map_" + ids[index] + "_y", clamp(y, 0f, 100f)).apply();
    }

    private void saveLayout() {
        for (int i = 0; i < ids.length; i++) saveOne(i);
        BotSettings.prefs(this).edit().putBoolean("layout_saved", true).apply();
        Toast.makeText(this, "11 titik HUD berhasil disimpan", Toast.LENGTH_SHORT).show();
    }

    private void resetDefaults() {
        android.content.SharedPreferences.Editor editor = BotSettings.prefs(this).edit();
        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            final TextView h = handles[i];
            float x = BotSettings.defaultX(ids[i]);
            float y = BotSettings.defaultY(ids[i]);
            editor.putFloat("map_" + ids[i] + "_x", x).putFloat("map_" + ids[i] + "_y", y);
            if (h != null) h.post(() -> {
                DisplayMetrics dm = screenMetrics();
                int[] canvasLocation = new int[2]; canvas.getLocationOnScreen(canvasLocation);
                float screenX = x / 100f * (dm.widthPixels - 1);
                float screenY = y / 100f * (dm.heightPixels - 1);
                h.setX(clamp(screenX - canvasLocation[0] - h.getWidth()/2f, 0, canvas.getWidth()-h.getWidth()));
                h.setY(clamp(screenY - canvasLocation[1] - h.getHeight()/2f, 0, canvas.getHeight()-h.getHeight()));
            });
        }
        editor.putBoolean("layout_saved", false).apply();
    }
    private Button actionButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(10); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(shape(0xFF263747, dp(9))); return b;
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        d.setStroke(dp(1), 0x8858DCC2); return d;
    }
    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private DisplayMetrics screenMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private static class GridBackground extends View {
        private final Paint paint = new Paint(3);
        GridBackground(android.content.Context c) { super(c); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); paint.setColor(0x223A6070); paint.setStrokeWidth(1);
            float step = 54f;
            for (float x = 0; x < getWidth(); x += step) c.drawLine(x, 0, x, getHeight(), paint);
            for (float y = 0; y < getHeight(); y += step) c.drawLine(0, y, getWidth(), y, paint);
            paint.setColor(0xFF91A3B4); paint.setTextSize(12);
            c.drawText("LANDSCAPE HUD PREVIEW  •  DRAG LABELS TO MATCH GAME CONTROLS", dp(getContext(), 12), getHeight()-dp(getContext(), 16), paint);
        }
        private static float dp(android.content.Context c, float v) { return v*c.getResources().getDisplayMetrics().density; }
    }
}
