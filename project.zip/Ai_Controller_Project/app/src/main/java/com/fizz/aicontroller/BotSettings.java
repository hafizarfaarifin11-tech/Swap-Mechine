package com.fizz.aicontroller;

import android.content.Context;
import android.content.SharedPreferences;

final class BotSettings {
    private static final String PREFS = "offline_bot_settings";
    private BotSettings() { }
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    static float value(Context c, String key, float fallback) { return prefs(c).getFloat(key, fallback); }
    static boolean flag(Context c, String key, boolean fallback) { return prefs(c).getBoolean(key, fallback); }
    static int integer(Context c, String key, int fallback) { return prefs(c).getInt(key, fallback); }
    static int px(Context c, String xKey, String yKey, boolean xAxis) {
        float p = value(c, xAxis ? xKey : yKey, xAxis ? 12f : 78f);
        int dimension = xAxis ? c.getResources().getDisplayMetrics().widthPixels : c.getResources().getDisplayMetrics().heightPixels;
        return Math.max(0, Math.min(dimension - 1, Math.round(dimension * p / 100f)));
    }
}
