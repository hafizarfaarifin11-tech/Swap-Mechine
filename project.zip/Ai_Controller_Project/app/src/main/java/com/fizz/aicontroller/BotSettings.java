package com.fizz.aicontroller;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.WindowManager;

final class BotSettings {
    private static final String PREFS = "ai_controller_settings";
    private BotSettings() { }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static float value(Context c, String key, float fallback) {
        return prefs(c).getFloat(key, fallback);
    }

    static boolean flag(Context c, String key, boolean fallback) {
        return prefs(c).getBoolean(key, fallback);
    }

    static int integer(Context c, String key, int fallback) {
        return prefs(c).getInt(key, fallback);
    }

    static float defaultX(String control) {
        switch (control) {
            case "move": return 13f;
            case "jump": return 91f;
            case "sprint": return 79f;
            case "crouch": return 83f;
            case "prone": return 72f;
            case "interact": return 65f;
            case "heal": return 91f;
            default: return 50f;
        }
    }

    static float defaultY(String control) {
        switch (control) {
            case "move": return 77f;
            case "jump": return 81f;
            case "sprint": return 68f;
            case "crouch": return 57f;
            case "prone": return 57f;
            case "interact": return 73f;
            case "heal": return 53f;
            default: return 50f;
        }
    }

    static float xPercent(Context c, String control) {
        return value(c, "map_" + control + "_x", defaultX(control));
    }

    static float yPercent(Context c, String control) {
        return value(c, "map_" + control + "_y", defaultY(control));
    }

    static int px(Context c, String control, boolean xAxis) {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        if (wm != null) wm.getDefaultDisplay().getRealMetrics(metrics);
        else metrics = c.getResources().getDisplayMetrics();
        int dimension = xAxis ? metrics.widthPixels : metrics.heightPixels;
        float percent = xAxis ? xPercent(c, control) : yPercent(c, control);
        return Math.max(0, Math.min(dimension - 1, Math.round(dimension * percent / 100f)));
    }

    static int px(Context c, String xKey, String yKey, boolean xAxis) {
        String control = xKey.replace("map_", "").replace("_x", "");
        if (control.endsWith("_y")) control = control.substring(0, control.length() - 2);
        return px(c, control, xAxis);
    }
}
