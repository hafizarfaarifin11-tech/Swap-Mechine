package com.fizz.aicontroller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.ByteBuffer;

public class CaptureBotService extends Service {
    static final String EXTRA_RESULT_CODE = "projection_result_code";
    static final String EXTRA_RESULT_DATA = "projection_result_data";
    private static final String CHANNEL_ID = "offline_bot_capture";
    private static final int NOTIFICATION_ID = 8060;
    private static final String ACTION_STOP = "com.fizz.aicontroller.STOP_BOT";
    private static final int ANALYSIS_WIDTH = 480;
    private static final long FRAME_INTERVAL_MS = 650;
    private static final long MOVE_GESTURE_MS = 460;

    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private TextView overlayStatus;
    private Button pauseButton;
    private boolean expanded;
    private boolean botEnabled = true;
    private boolean isStopping;
    private float downRawX, downRawY;
    private int startWindowX, startWindowY;
    private boolean dragging;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread frameThread;
    private Handler frameHandler;
    private int screenWidth, screenHeight, densityDpi;
    private long lastProcessedFrame, lastHopTime, lastCueTime, lastMoveTime, lastZigzagSwitch;
    private boolean zigzagRight = true;
    private float smoothX = 0.5f, smoothY = 0.5f;
    private boolean hasSmoothedCue;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            toast("Izin overlay belum aktif"); stopSelf(); return START_NOT_STICKY;
        }
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_CODE) || !intent.hasExtra(EXTRA_RESULT_DATA)) {
            toast("Izin Screen Capture belum diberikan. Mulai dari aplikasi."); stopSelf(); return START_NOT_STICKY;
        }
        startAsForeground();
        try {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData = getResultData(intent);
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("MediaProjection tidak tersedia");
            projection.registerCallback(new MediaProjection.Callback() { @Override public void onStop() { stopSelf(); } }, new Handler(getMainLooper()));
            startCapturePipeline();
            showBubble();
        } catch (Exception e) {
            toast("Bot gagal mulai: " + e.getMessage()); stopSelf();
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation") private Intent getResultData(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) return source.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        return source.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private void startAsForeground() {
        Intent stop = new Intent(this, CaptureBotService.class); stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 61, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 62, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("AI Controller • Movement Bot")
                .setContentText("Analisis visual lokal aktif • frame tidak disimpan")
                .setContentIntent(openPending).setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_launcher), "Stop", stopPending).build());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            startForeground(NOTIFICATION_ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIFICATION_ID, builder.build());
    }

    private void startCapturePipeline() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        densityDpi = metrics.densityDpi;
        float scale = Math.min(1f, ANALYSIS_WIDTH / (float) Math.max(metrics.widthPixels, metrics.heightPixels));
        screenWidth = Math.max(240, Math.round(metrics.widthPixels * scale));
        screenHeight = Math.max(135, Math.round(metrics.heightPixels * scale));
        frameThread = new HandlerThread("OfflineBotVision"); frameThread.start();
        frameHandler = new Handler(frameThread.getLooper());
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, frameHandler);
        virtualDisplay = projection.createVirtualDisplay("AIControllerMovementVision", screenWidth, screenHeight, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, frameHandler);
        if (virtualDisplay == null) throw new IllegalStateException("VirtualDisplay gagal dibuat");
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastProcessedFrame < FRAME_INTERVAL_MS) return;
            lastProcessedFrame = now;
            if (!botEnabled || isStopping) return;
            Bitmap frame = imageToBitmap(image);
            if (frame == null) return;
            int color = BotSettings.integer(this, "cue_color", 0);
            int sensitivity = BotSettings.integer(this, "sensitivity", 25);
            NavigationCueDetector.Cue cue = NavigationCueDetector.detect(frame, color, sensitivity);
            frame.recycle();
            int strategy = BotSettings.integer(this, "strategy", 0);
            if (strategy == 0) {
                if (cue == null) {
                    if (now - lastCueTime > 1400) {
                        hasSmoothedCue = false;
                        updateOverlayStatus("Marker tidak terlihat • bot menunggu");
                    } else updateOverlayStatus("Mencari marker navigasi…");
                    return;
                }
                lastCueTime = now;
                smoothX = hasSmoothedCue ? (smoothX * 0.62f + cue.centerX * 0.38f) : cue.centerX;
                smoothY = hasSmoothedCue ? (smoothY * 0.62f + cue.centerY * 0.38f) : cue.centerY;
                hasSmoothedCue = true;
                runMovementDecision(smoothX, smoothY, cue.area, now);
            } else {
                runPatternDecision(strategy, cue != null, now);
            }
        } catch (Exception ignored) {
            updateOverlayStatus("Frame gagal dianalisis • cek izin capture");
        } finally { if (image != null) image.close(); }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) return null;
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int paddedWidth = rowStride / pixelStride;
        Bitmap padded = Bitmap.createBitmap(paddedWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
        buffer.rewind(); padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
        padded.recycle(); return cropped;
    }

    private void runMovementDecision(float cueX, float cueY, int area, long now) {
        if (!GameInputAccessibilityService.isReady()) { updateOverlayStatus("Marker terlihat, aktifkan Accessibility untuk gesture"); return; }
        if (GameInputAccessibilityService.isBusy()) return;

        float dx = cueX - 0.5f;
        float dy = cueY - 0.5f;
        final float deadZone = 0.075f;
        if (Math.abs(dx) < deadZone) dx = 0f;
        if (Math.abs(dy) < deadZone) dy = 0f;

        boolean autoHop = BotSettings.flag(this, "auto_hop", true);
        int hopInterval = BotSettings.integer(this, "hop_interval", 1800);
        boolean hopDue = autoHop && now - lastHopTime >= hopInterval;
        if (hopDue) {
            int jumpX = BotSettings.px(this, "jump_x", "jump_y", true);
            int jumpY = BotSettings.px(this, "jump_x", "jump_y", false);
            GameInputAccessibilityService.tap(jumpX, jumpY, 75);
            lastHopTime = now;
            updateOverlayStatus("Marker " + Math.round(cueX * 100) + "," + Math.round(cueY * 100) + "% • HOP");
            return;
        }

        if (dx == 0f && dy == 0f) {
            updateOverlayStatus("Marker dekat tengah • posisi tercapai, menunggu hop");
            return;
        }
        int baseX = BotSettings.px(this, "move_x", "move_y", true);
        int baseY = BotSettings.px(this, "move_x", "move_y", false);
        float radiusPercent = BotSettings.value(this, "move_radius", 9f);
        float radius = Math.max(18f, Math.min(screenWidth, screenHeight) * radiusPercent / 100f);
        // Cue to the right/up drives the joystick right/up. The scale is damped to avoid edge flicker.
        int endX = clamp(Math.round(baseX + clampFloat(dx * 2.6f, -1f, 1f) * radius), 2, getDisplayWidth() - 3);
        int endY = clamp(Math.round(baseY + clampFloat(dy * 2.6f, -1f, 1f) * radius), 2, getDisplayHeight() - 3);
        GameInputAccessibilityService.swipe(baseX, baseY, endX, endY, MOVE_GESTURE_MS);
        lastMoveTime = now;
        String horizontal = dx < 0 ? "KIRI" : (dx > 0 ? "KANAN" : "LURUS");
        String vertical = dy < -deadZone ? "MAJU" : (dy > deadZone ? "MUNDUR" : "" );
        updateOverlayStatus("Cue " + Math.round(cueX * 100) + "," + Math.round(cueY * 100) + "% • " + vertical + " " + horizontal + " • area " + area);
    }


    private void runPatternDecision(int strategy, boolean cueVisible, long now) {
        if (!GameInputAccessibilityService.isReady()) {
            updateOverlayStatus("Aktifkan Accessibility untuk mengirim gerakan");
            return;
        }
        if (GameInputAccessibilityService.isBusy()) return;
        int baseX = BotSettings.px(this, "move_x", "move_y", true);
        int baseY = BotSettings.px(this, "move_x", "move_y", false);
        float radiusPercent = BotSettings.value(this, "move_radius", 9f);
        float radius = Math.max(18f, Math.min(screenWidth, screenHeight) * radiusPercent / 100f);

        if (strategy == 2 && now - lastZigzagSwitch >= 1450) {
            zigzagRight = !zigzagRight;
            lastZigzagSwitch = now;
        }
        boolean hopDue = BotSettings.flag(this, "auto_hop", true)
                && now - lastHopTime >= BotSettings.integer(this, "hop_interval", 1800);
        if (hopDue) {
            int jumpX = BotSettings.px(this, "jump_x", "jump_y", true);
            int jumpY = BotSettings.px(this, "jump_x", "jump_y", false);
            GameInputAccessibilityService.tap(jumpX, jumpY, 75);
            lastHopTime = now;
            updateOverlayStatus((strategy == 2 ? "Zig-zag" : "Maju") + " • HOP" + (cueVisible ? " • cue terdeteksi" : ""));
            return;
        }

        float side = strategy == 2 ? (zigzagRight ? 0.62f : -0.62f) : 0f;
        int endX = clamp(Math.round(baseX + side * radius), 2, getDisplayWidth() - 3);
        int endY = clamp(Math.round(baseY - radius), 2, getDisplayHeight() - 3);
        GameInputAccessibilityService.swipe(baseX, baseY, endX, endY, MOVE_GESTURE_MS);
        lastMoveTime = now;
        updateOverlayStatus((strategy == 2 ? (zigzagRight ? "Zig-zag kanan" : "Zig-zag kiri") : "Maju")
                + (cueVisible ? " • cue terlihat" : " • pola latihan")
                + (BotSettings.flag(this, "auto_hop", true) ? " • hop aktif" : ""));
    }

    private int getDisplayWidth() { return getResources().getDisplayMetrics().widthPixels; }
    private int getDisplayHeight() { return getResources().getDisplayMetrics().heightPixels; }
    private int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private float clampFloat(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }

    private void showBubble() {
        TextView bubble = new TextView(this);
        bubble.setText("AI"); bubble.setTextColor(0xFF07120F); bubble.setTextSize(13);
        bubble.setTypeface(null, 1); bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(round(0xFF36D6B0, dp(28)));
        overlayParams = new WindowManager.LayoutParams(dp(58), dp(54),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = dp(10); overlayParams.y = dp(185); overlayView = bubble;
        bubble.setOnTouchListener((v, event) -> handleBubbleTouch(event));
        try { windowManager.addView(overlayView, overlayParams); }
        catch (Exception e) { overlayView = null; toast("Overlay gagal ditampilkan"); }
    }

    private boolean handleBubbleTouch(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = event.getRawX(); downRawY = event.getRawY();
                startWindowX = overlayParams.x; startWindowY = overlayParams.y;
                dragging = false; return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX, dy = event.getRawY() - downRawY;
                if (Math.abs(dx) + Math.abs(dy) > dp(7)) dragging = true;
                if (dragging) {
                    overlayParams.x = startWindowX + Math.round(dx);
                    overlayParams.y = startWindowY + Math.round(dy);
                    try { windowManager.updateViewLayout(overlayView, overlayParams); } catch (Exception ignored) { }
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (!dragging) showPanel();
                return true;
            default: return true;
        }
    }

    private void showPanel() {
        if (overlayView == null || expanded) return;
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12)); panel.setBackground(round(0xF0161F2A, dp(16)));
        TextView title = new TextView(this); title.setText("MOVEMENT BOT • v0.6");
        title.setTextColor(0xFF36D6B0); title.setTypeface(null, 1); panel.addView(title);
        overlayStatus = new TextView(this); overlayStatus.setText("Menunggu marker navigasi…");
        overlayStatus.setTextColor(0xFFFFFFFF); overlayStatus.setTextSize(11);
        overlayStatus.setPadding(0, dp(8), 0, dp(8)); panel.addView(overlayStatus);
        pauseButton = panelButton(botEnabled ? "PAUSE BOT" : "RESUME BOT"); panel.addView(pauseButton);
        pauseButton.setOnClickListener(v -> {
            botEnabled = !botEnabled;
            pauseButton.setText(botEnabled ? "PAUSE BOT" : "RESUME BOT");
            updateOverlayStatus(botEnabled ? "Bot dilanjutkan" : "Bot dijeda");
        });
        Button close = panelButton("MINIMIZE"); panel.addView(close);
        close.setOnClickListener(v -> showBubbleAgain());
        Button stop = panelButton("STOP BOT & SCREEN CAPTURE"); panel.addView(stop);
        stop.setOnClickListener(v -> stopSelf());
        replaceOverlay(panel, dp(240), -2); expanded = true;
    }

    private Button panelButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF); b.setBackground(round(0xFF263746, dp(9)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(40)); p.topMargin = dp(5); b.setLayoutParams(p);
        return b;
    }
    private void showBubbleAgain() {
        expanded = false;
        if (overlayView != null) { try { windowManager.removeView(overlayView); } catch (Exception ignored) { } overlayView = null; }
        showBubble();
    }
    private void replaceOverlay(View view, int width, int height) {
        try {
            if (overlayView != null) windowManager.removeView(overlayView);
            overlayView = view; overlayParams.width = width; overlayParams.height = height;
            windowManager.addView(overlayView, overlayParams);
        } catch (Exception e) { overlayView = null; stopSelf(); }
    }
    private void updateOverlayStatus(String value) {
        new Handler(getMainLooper()).post(() -> { if (overlayStatus != null) overlayStatus.setText(value); });
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Offline Bot Screen Analysis", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Sesi analisis visual lokal; frame tidak disimpan");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    private android.graphics.drawable.GradientDrawable round(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }

    @Override public void onDestroy() {
        isStopping = true;
        try { if (overlayView != null) windowManager.removeView(overlayView); } catch (Exception ignored) { }
        overlayView = null; overlayStatus = null;
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) { }
        virtualDisplay = null;
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) { }
        imageReader = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        projection = null;
        if (frameThread != null) { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) frameThread.quitSafely(); frameThread = null; }
        stopForeground(true); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
