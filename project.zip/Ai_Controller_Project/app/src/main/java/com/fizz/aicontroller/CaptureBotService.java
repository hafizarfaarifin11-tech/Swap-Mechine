package com.fizz.aicontroller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureBotService extends Service {
    static final String EXTRA_RESULT_CODE = "projection_result_code";
    static final String EXTRA_RESULT_DATA = "projection_result_data";
    private static final String CHANNEL_ID = "offline_bot_capture_v10";
    private static final int NOTIFICATION_ID = 8070;
    private static final String ACTION_STOP = "com.fizz.aicontroller.STOP_BOT";
    private static final int MAX_ANALYSIS_SIDE = 640;
    private static final long MOVE_GESTURE_MS = 1400;

    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private TextView overlayStatus, overlayInfo;
    private Button pauseButton;
    private ControlHudView controlHudView;
    private InGameLayoutEditor inGameLayoutEditor;
    private WindowManager.LayoutParams hudParams;
    private boolean expanded;
    private boolean botEnabled = false;
    private boolean isStopping;
    private boolean hudVisible = true;
    private float downRawX, downRawY;
    private int startWindowX, startWindowY;
    private boolean dragging;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread frameThread;
    private Handler frameHandler;
    private ExecutorService analysisExecutor;
    private TextRecognizer textRecognizer;
    private Handler mainHandler;
    private final AtomicBoolean analyzing = new AtomicBoolean(false);
    private int screenWidth, screenHeight, densityDpi;
    private long lastProcessedFrame, lastHopTime, lastCueTime, lastMoveTime, lastZigzagSwitch, lastActionTime;
    private long lastDefenseTime, lastZoneSprintTime, lastCameraScanTime;
    private boolean cameraScanRight = true;
    private boolean defenseSequenceActive;
    private boolean autoSprintSent;
    private Runnable autoSprintWatcher;
    private float previousHealthRatio = -1f;
    private boolean zigzagRight = true;
    private float smoothX = 0.5f, smoothY = 0.5f;
    private boolean hasSmoothedCue;
    private byte[] previousSceneSample;
    private int stagnantSamples;
    private int avoidanceDirection;
    private long avoidanceUntil;
    private long lastAvoidanceAt;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler = new Handler(getMainLooper());
        analysisExecutor = Executors.newSingleThreadExecutor();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { toast("Izin overlay belum aktif"); stopSelf(); return START_NOT_STICKY; }
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_CODE) || !intent.hasExtra(EXTRA_RESULT_DATA)) {
            toast("Izin screen capture belum diberikan. Mulai dari aplikasi."); stopSelf(); return START_NOT_STICKY;
        }
        startAsForeground();
        try {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData = getResultData(intent);
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("MediaProjection tidak tersedia");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopSelf(); }
            }, new Handler(getMainLooper()));
            startCapturePipeline();
            showControlHud();
            showBubble();
            updateOverlayStatus("v1.0.0 siap • buka game lalu tekan RESUME BOT di bubble");
            if (BotSettings.flag(this, "auto_sprint", true)) {
                autoSprintWatcher = new Runnable() {
                    @Override public void run() {
                        if (isStopping || autoSprintSent) return;
                        if (botEnabled && GameInputAccessibilityService.isExternalAppVisible() && !GameInputAccessibilityService.isBusy()) {
                            GameInputAccessibilityService.tapControl(CaptureBotService.this, "sprint");
                            autoSprintSent = true;
                            updateOverlayStatus("Game terdeteksi • auto sprint dikirim");
                        } else {
                            mainHandler.postDelayed(this, 800);
                        }
                    }
                };
                mainHandler.postDelayed(autoSprintWatcher, 900);
            }
        } catch (Exception e) { toast("Bot gagal mulai: " + e.getMessage()); stopSelf(); }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation") private Intent getResultData(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) return source.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        return source.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private void startAsForeground() {
        Intent stop = new Intent(this, CaptureBotService.class); stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 71, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 72, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher).setContentTitle("AI Controller • Survival Assistant")
                .setContentText("Kontrol dan analisis HUD lokal • frame tidak disimpan")
                .setContentIntent(openPending).setOngoing(true)
                .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_launcher), "Stop", stopPending).build());
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIFICATION_ID, builder.build());
    }

    private void startCapturePipeline() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        densityDpi = metrics.densityDpi;
        float scale = Math.min(1f, MAX_ANALYSIS_SIDE / (float)Math.max(metrics.widthPixels, metrics.heightPixels));
        screenWidth = Math.max(240, Math.round(metrics.widthPixels * scale));
        screenHeight = Math.max(135, Math.round(metrics.heightPixels * scale));
        frameThread = new HandlerThread("AIControllerFrameReader"); frameThread.start();
        frameHandler = new Handler(frameThread.getLooper());
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, frameHandler);
        virtualDisplay = projection.createVirtualDisplay("AIControllerHUDReader", screenWidth, screenHeight, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, frameHandler);
        if (virtualDisplay == null) throw new IllegalStateException("VirtualDisplay gagal dibuat");
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null; Bitmap frame = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = SystemClock.elapsedRealtime();
            int interval = BotSettings.integer(this, "frame_interval", 720);
            if (now - lastProcessedFrame < interval) return;
            lastProcessedFrame = now;
            if (!botEnabled || isStopping || !analyzing.compareAndSet(false, true)) return;
            frame = imageToBitmap(image);
        } catch (Exception e) {
            analyzing.set(false); updateOverlayStatus("Gagal membaca frame");
        } finally { if (image != null) image.close(); }
        if (frame == null) { analyzing.set(false); return; }
        final Bitmap captured = frame;
        final long capturedAt = SystemClock.elapsedRealtime();
        int strategy = BotSettings.integer(this, "strategy", 0);
        if (strategy == 4 || strategy == 5) {
            // OCR is run only in HUD-reader or survival mode.
            try {
                if (textRecognizer == null) textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                Task<Text> task = textRecognizer.process(InputImage.fromBitmap(captured, 0));
                task.addOnSuccessListener(analysisExecutor, result -> handleAnalysis(captured, result, capturedAt));
                task.addOnFailureListener(analysisExecutor, error -> updateOverlayStatus("OCR gagal • " + safeMessage(error.getMessage())));
                task.addOnCompleteListener(analysisExecutor, done -> {
                    if (!captured.isRecycled()) captured.recycle();
                    analyzing.set(false);
                });
            } catch (Exception e) {
                if (!captured.isRecycled()) captured.recycle();
                analyzing.set(false); updateOverlayStatus("OCR belum siap • " + safeMessage(e.getMessage()));
            }
        } else {
            // Movement and marker modes do not pay the OCR cost on every frame.
            try {
                analysisExecutor.execute(() -> {
                    try { handleVisualAnalysis(captured, strategy, capturedAt); }
                    catch (Exception e) { updateOverlayStatus("Analisis visual gagal • " + safeMessage(e.getMessage())); }
                    finally {
                        if (!captured.isRecycled()) captured.recycle();
                        analyzing.set(false);
                    }
                });
            } catch (Exception e) {
                if (!captured.isRecycled()) captured.recycle();
                analyzing.set(false);
                updateOverlayStatus("Worker analisis berhenti • " + safeMessage(e.getMessage()));
            }
        }
    }

    private void handleAnalysis(Bitmap frame, Text recognized, long now) {
        if (isStopping || !botEnabled) return;
        if (!GameInputAccessibilityService.isExternalAppVisible()) {
            updateOverlayStatus("Menunggu game dibuka • input belum dikirim");
            return;
        }
        String raw = recognized == null ? "" : recognized.getText();
        String compact = raw == null ? "" : raw.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (compact.length() > 140) compact = compact.substring(0, 140) + "…";
        updateOverlayInfo(compact.isEmpty() ? "HUD TEXT: tidak ada teks terbaca" : "HUD TEXT: " + compact);
        if (BotSettings.integer(this, "strategy", 0) == 5) {
            runSurvivalAnalysis(raw, frame, now);
            runAutoNavigation(now, measureSceneMotion(frame));
        } else {
            LocalGameAnalyzer.Advice advice = LocalGameAnalyzer.analyze(raw);
            updateOverlayStatus(advice.title + " • " + advice.detail);
            runTextAction(advice, now);
        }
    }

    private void handleVisualAnalysis(Bitmap frame, int strategy, long now) {
        if (isStopping || !botEnabled) return;
        if (!GameInputAccessibilityService.isExternalAppVisible()) {
            updateOverlayStatus("Menunggu game dibuka • input belum dikirim");
            return;
        }
        if (strategy == 1) {
            int color = BotSettings.integer(this, "cue_color", 0);
            int sensitivity = BotSettings.integer(this, "sensitivity", 25);
            NavigationCueDetector.Cue cue = NavigationCueDetector.detect(frame, color, sensitivity);
            if (cue == null) {
                updateOverlayInfo("VISION: marker warna belum ditemukan");
                if (now - lastCueTime > 1500) { hasSmoothedCue = false; updateOverlayStatus("Marker tidak terlihat • menunggu"); }
                else updateOverlayStatus("Mencari marker warna…");
                return;
            }
            updateOverlayInfo("VISION: marker terdeteksi • area " + cue.area);
            lastCueTime = now;
            smoothX = hasSmoothedCue ? smoothX * 0.65f + cue.centerX * 0.35f : cue.centerX;
            smoothY = hasSmoothedCue ? smoothY * 0.65f + cue.centerY * 0.35f : cue.centerY;
            hasSmoothedCue = true;
            runMovementDecision(smoothX, smoothY, cue.area, now);
            return;
        }

        float motion = measureSceneMotion(frame);
        updateOverlayInfo("VISION: perubahan layar " + String.format(java.util.Locale.US, "%.1f", motion));
        if (strategy == 0) {
            runAutoNavigation(now, motion);
        } else {
            runPatternDecision(strategy, now);
        }
    }

    /**
     * Estimates visible scene change in a small central crop. A low score for
     * several consecutive samples while auto-steering is active is treated as
     * a possible collision/stuck state, not proof that a wall was identified.
     */
    private float measureSceneMotion(Bitmap bitmap) {
        final int sampleW = 48, sampleH = 28;
        final int width = bitmap.getWidth(), height = bitmap.getHeight();
        byte[] current = new byte[sampleW * sampleH];
        for (int sy = 0; sy < sampleH; sy++) {
            int y = (int) (height * (0.18f + 0.64f * (sy / (float) (sampleH - 1))));
            for (int sx = 0; sx < sampleW; sx++) {
                int x = (int) (width * (0.12f + 0.76f * (sx / (float) (sampleW - 1))));
                int color = bitmap.getPixel(Math.min(width - 1, x), Math.min(height - 1, y));
                int r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
                current[sy * sampleW + sx] = (byte) ((r * 77 + g * 150 + b * 29) >> 8);
            }
        }
        byte[] previous = previousSceneSample;
        previousSceneSample = current;
        if (previous == null || previous.length != current.length) return 255f;
        long total = 0;
        for (int i = 0; i < current.length; i++) total += Math.abs((current[i] & 255) - (previous[i] & 255));
        return total / (float) current.length;
    }

    private void runAutoNavigation(long now, float motionScore) {
        if (defenseSequenceActive) return;
        if (!GameInputAccessibilityService.isReady()) {
            updateOverlayStatus("Mode AUTO siap • aktifkan Accessibility agar joystick bisa digerakkan");
            return;
        }
        if (GameInputAccessibilityService.isBusy() || now - lastMoveTime < MOVE_GESTURE_MS) return;

        // A stable image is only a possible collision signal; it is not a true wall detector.
        if (motionScore < 2.8f) stagnantSamples++;
        else stagnantSamples = 0;
        if (stagnantSamples >= 3 && now - lastAvoidanceAt > 3200) {
            avoidanceDirection = (avoidanceDirection + 1) % 3;
            avoidanceUntil = now + 2400;
            lastAvoidanceAt = now;
            stagnantSamples = 0;
            updateOverlayStatus("Kemungkinan mentok • kamera diputar dan mencoba jalur lain");
            GameInputAccessibilityService.panCamera(this, 0.19f, 0f, 430);
            final float ax = avoidanceDirection == 1 ? 0.82f : avoidanceDirection == 2 ? -0.82f : 0f;
            final float ay = avoidanceDirection == 0 ? 0.72f : -0.55f;
            mainHandler.postDelayed(() -> {
                if (!isStopping && botEnabled && !GameInputAccessibilityService.isBusy()) {
                    dispatchMoveVector(ax, ay, SystemClock.elapsedRealtime(), "ANTI-STUCK: mencoba arah alternatif");
                }
            }, 560);
            return;
        }

        if (BotSettings.flag(this, "auto_camera", false) && now - lastCameraScanTime >= 7000 && !GameInputAccessibilityService.isBusy()) {
            GameInputAccessibilityService.panCamera(this, cameraScanRight ? 0.075f : -0.075f, 0f, 380);
            cameraScanRight = !cameraScanRight;
            lastCameraScanTime = now;
            updateOverlayStatus("AUTO: kamera dipindai perlahan");
            return;
        }

        if (BotSettings.flag(this, "auto_hop", true) && now - lastHopTime >= BotSettings.integer(this, "hop_interval", 3000)) {
            GameInputAccessibilityService.tapControl(this, "jump");
            lastHopTime = now;
            updateOverlayStatus("AUTO: lompat berkala");
            return;
        }

        float x = 0f, y = -1f;
        String direction = "maju";
        if (now < avoidanceUntil) {
            if (avoidanceDirection == 1) { x = 0.82f; y = -0.55f; direction = "serong kanan"; }
            else if (avoidanceDirection == 2) { x = -0.82f; y = -0.55f; direction = "serong kiri"; }
            else { x = 0f; y = 0.72f; direction = "mundur"; }
        }
        dispatchMoveVector(x, y, now, "AUTO: menahan joystick " + direction + " • visual " + String.format(java.util.Locale.US, "%.1f", motionScore));
    }

    private void runSurvivalAnalysis(String rawText, Bitmap frame, long now) {
        String t = rawText == null ? "" : rawText.toUpperCase(java.util.Locale.ROOT)
                .replace('\n', ' ').replaceAll("\\s+", " ").trim();
        boolean outsideZone = containsAny(t, "OUTSIDE SAFE ZONE", "OUTSIDE THE SAFE ZONE", "ZONE SHRINKING", "SAFE ZONE IS SHRINKING", "ZONE IS SHRINKING", "OUT OF ZONE", "DI LUAR ZONA AMAN", "DI LUAR ZONA", "ZONA AMAN MENYUSUT", "ZONA MENYUSUT");
        boolean zoneNotice = outsideZone || containsAny(t, "SAFE ZONE", "ZONE SHRINK", "ZONE CLOSING", "ZONE WILL SHRINK", "ZONA AMAN");
        boolean danger = containsAny(t, "SURROUNDED", "ENEMY NEAR", "ENEMIES NEAR", "DANGER NEAR", "UNDER FIRE", "YOU ARE ATTACKED", "BEING ATTACKED", "DANGER", "DIKEPUNG", "MUSUH DEKAT", "BAHAYA", "DISERANG", "TERSERANG");
        float health = estimateHealthRatio(frame);
        boolean healthDrop = health >= 0f && previousHealthRatio >= 0f && previousHealthRatio - health >= 0.045f;
        boolean lowHealth = health >= 0f && health <= 0.55f;
        if (health >= 0f) previousHealthRatio = health;

        String healthText = health < 0f ? "HP: belum dikalibrasi" : "HP kira-kira " + Math.round(health * 100f) + "%";
        if (zoneNotice) {
            updateOverlayStatus((outsideZone ? "ZONA: peringatan di luar/menyusut" : "ZONA: teks zona terdeteksi") + " • " + healthText);
            if (outsideZone && !BotSettings.flag(this, "auto_sprint", true) && now - lastZoneSprintTime > 8500 && !GameInputAccessibilityService.isBusy()) {
                GameInputAccessibilityService.tapControl(this, "sprint");
                lastZoneSprintTime = now;
            }
        } else if (lowHealth || healthDrop || danger) {
            updateOverlayStatus((danger ? "BAHAYA terdeteksi" : "Perubahan HP terdeteksi") + " • " + healthText);
        } else {
            updateOverlayStatus("SURVIVAL aktif • " + healthText + (t.isEmpty() ? " • menunggu HUD" : " • HUD dipantau"));
        }

        if ((danger || healthDrop || lowHealth) && now - lastDefenseTime > 14000) {
            startDefensiveRingAndHeal(danger ? "indikasi bahaya pada HUD" : "HP menurun/rendah");
        }
    }

    private float estimateHealthRatio(Bitmap frame) {
        if (frame == null || frame.isRecycled()) return -1f;
        float x1p = BotSettings.xPercent(this, "hp_start") / 100f;
        float y1p = BotSettings.yPercent(this, "hp_start") / 100f;
        float x2p = BotSettings.xPercent(this, "hp_end") / 100f;
        float y2p = BotSettings.yPercent(this, "hp_end") / 100f;
        int w = frame.getWidth(), h = frame.getHeight();
        float x1 = x1p * (w - 1), y1 = y1p * (h - 1);
        float x2 = x2p * (w - 1), y2 = y2p * (h - 1);
        int samples = 120, active = 0;
        for (int i = 0; i < samples; i++) {
            float f = (i + 0.5f) / samples;
            int x = Math.max(0, Math.min(w - 1, Math.round(x1 + (x2 - x1) * f)));
            int y = Math.max(0, Math.min(h - 1, Math.round(y1 + (y2 - y1) * f)));
            boolean found = false;
            for (int off = -2; off <= 2; off++) {
                int yy = Math.max(0, Math.min(h - 1, y + off));
                if (isHealthBarColor(frame.getPixel(x, yy))) { found = true; break; }
            }
            if (found) active++;
        }
        float ratio = active / (float) samples;
        // A result near zero usually means the selected line missed the bar.
        return ratio < 0.025f ? -1f : Math.min(1f, ratio);
    }

    private boolean isHealthBarColor(int color) {
        int r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        if (max - min < 42) return false;
        boolean red = r > 100 && r > g * 1.28f && r > b * 1.15f;
        boolean green = g > 95 && g > r * 1.18f && g > b * 1.04f;
        return red || green;
    }

    private boolean containsAny(String text, String... terms) {
        for (String term : terms) if (text.contains(term)) return true;
        return false;
    }

    private void startDefensiveRingAndHeal(String reason) {
        if (defenseSequenceActive || isStopping || !GameInputAccessibilityService.isReady()) return;
        defenseSequenceActive = true;
        lastDefenseTime = SystemClock.elapsedRealtime();
        updateOverlayStatus("DEFENSE: rangkaian Gloo Wall dimulai • " + reason);
        // Four wall placements with short camera turns form an approximate ring.
        // Exact placement depends on the game's mapped Gloo button behavior.
        for (int i = 0; i < 4; i++) {
            final int step = i;
            mainHandler.postDelayed(() -> {
                if (!isStopping && botEnabled && GameInputAccessibilityService.isReady()) {
                    GameInputAccessibilityService.tapControl(this, "gloo");
                    updateOverlayStatus("DEFENSE: Gloo Wall " + (step + 1) + "/4");
                }
            }, 1650L + i * 1050L);
            if (i < 3) {
                mainHandler.postDelayed(() -> {
                    if (!isStopping && botEnabled && GameInputAccessibilityService.isReady())
                        GameInputAccessibilityService.panCamera(this, 0.18f, 0f, 420);
                }, 1650L + i * 1050L + 430L);
            }
        }
        mainHandler.postDelayed(() -> {
            if (!isStopping && botEnabled && GameInputAccessibilityService.isReady()) {
                GameInputAccessibilityService.tapControl(this, "crouch");
                updateOverlayStatus("DEFENSE: posisi jongkok");
            }
        }, 5350L);
        mainHandler.postDelayed(() -> {
            if (!isStopping && botEnabled && GameInputAccessibilityService.isReady()) {
                GameInputAccessibilityService.tapControl(this, "heal");
                updateOverlayStatus("DEFENSE: tombol heal dikirim");
            }
        }, 6200L);
        mainHandler.postDelayed(() -> defenseSequenceActive = false, 7200L);
    }

    private void runTextAction(LocalGameAnalyzer.Advice advice, long now) {
        if (!BotSettings.flag(this, "auto_hud_actions", false)) return;
        if (now - lastActionTime < 4200 || !GameInputAccessibilityService.isReady() || GameInputAccessibilityService.isBusy()) return;
        if (advice.action == LocalGameAnalyzer.SPRINT) {
            GameInputAccessibilityService.tapControl(this, "sprint");
            lastActionTime = now;
            updateOverlayStatus("AI ACTION: tombol LARI ditekan berdasarkan teks zona");
        } else if (advice.action == LocalGameAnalyzer.INTERACT) {
            GameInputAccessibilityService.tapControl(this, "interact");
            lastActionTime = now;
            updateOverlayStatus("AI ACTION: tombol INTERAKSI ditekan berdasarkan prompt HUD");
        } else if (advice.action == LocalGameAnalyzer.CROUCH) {
            GameInputAccessibilityService.tapControl(this, "crouch");
            lastActionTime = now;
            updateOverlayStatus("AI ACTION: tombol JONGKOK ditekan berdasarkan peringatan HUD");
        } else if (advice.action == LocalGameAnalyzer.PRONE) {
            GameInputAccessibilityService.tapControl(this, "prone");
            lastActionTime = now;
            updateOverlayStatus("AI ACTION: tombol TIARAP ditekan berdasarkan petunjuk HUD");
        } else if (advice.action == LocalGameAnalyzer.HEAL) {
            GameInputAccessibilityService.tapControl(this, "heal");
            lastActionTime = now;
            updateOverlayStatus("AI ACTION: tombol HEAL ditekan berdasarkan petunjuk HUD");
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) return null;
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int paddedWidth = rowStride / pixelStride;
        Bitmap padded = Bitmap.createBitmap(paddedWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
        buffer.rewind(); padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
        padded.recycle(); return cropped;
    }

    private void runMovementDecision(float cueX, float cueY, int area, long now) {
        if (!GameInputAccessibilityService.isReady()) { updateOverlayStatus("Marker terlihat; aktifkan Accessibility untuk gesture"); return; }
        if (GameInputAccessibilityService.isBusy() || now - lastMoveTime < MOVE_GESTURE_MS) return;
        float dx = cueX - 0.5f, dy = cueY - 0.5f;
        final float deadZone = 0.075f;
        if (Math.abs(dx) < deadZone) dx = 0f;
        if (Math.abs(dy) < deadZone) dy = 0f;
        if (BotSettings.flag(this, "auto_hop", true) && now - lastHopTime >= BotSettings.integer(this, "hop_interval", 1800)) {
            GameInputAccessibilityService.tapControl(this, "jump"); lastHopTime = now;
            updateOverlayStatus("Marker terlihat • lompat"); return;
        }
        if (dx == 0f && dy == 0f) { updateOverlayStatus("Marker dekat tengah • menunggu"); return; }
        GameInputAccessibilityService.moveJoystick(this, clampFloat(dx * 2.5f, -1f, 1f), clampFloat(dy * 2.5f, -1f, 1f), MOVE_GESTURE_MS);
        lastMoveTime = now;
        updateOverlayStatus("Vision marker: " + (dx < 0 ? "kiri" : dx > 0 ? "kanan" : "lurus") + " • area " + area);
    }

    private void runPatternDecision(int strategy, long now) {
        if (!GameInputAccessibilityService.isReady()) { updateOverlayStatus("Aktifkan Accessibility untuk menggerakkan kontrol"); return; }
        if (GameInputAccessibilityService.isBusy() || now - lastMoveTime < MOVE_GESTURE_MS) return;
        if (strategy == 3 && now - lastZigzagSwitch >= 1500) { zigzagRight = !zigzagRight; lastZigzagSwitch = now; }
        if (BotSettings.flag(this, "auto_hop", true) && now - lastHopTime >= BotSettings.integer(this, "hop_interval", 3000)) {
            GameInputAccessibilityService.tapControl(this, "jump"); lastHopTime = now; updateOverlayStatus("Pola latihan • lompat"); return;
        }
        float side = strategy == 3 ? (zigzagRight ? 0.55f : -0.55f) : 0f;
        dispatchMoveVector(side, -1f, now, strategy == 3 ? (zigzagRight ? "Pola zig-zag kanan" : "Pola zig-zag kiri") : "Pola maju");
        if (BotSettings.flag(this, "auto_hud_actions", false) && now - lastActionTime > 10000) {
            GameInputAccessibilityService.tapControl(this, "sprint"); lastActionTime = now;
        }
    }

    private void dispatchMoveVector(float x, float y, long now, String status) {
        GameInputAccessibilityService.moveJoystick(this, x, y, MOVE_GESTURE_MS);
        lastMoveTime = now;
        updateOverlayStatus(status);
    }

    private int getDisplayWidth() { DisplayMetrics m = new DisplayMetrics(); windowManager.getDefaultDisplay().getRealMetrics(m); return m.widthPixels; }
    private int getDisplayHeight() { DisplayMetrics m = new DisplayMetrics(); windowManager.getDefaultDisplay().getRealMetrics(m); return m.heightPixels; }
    private int clamp(int v,int min,int max) { return Math.max(min,Math.min(max,v)); }
    private float clampFloat(float v,float min,float max) { return Math.max(min,Math.min(max,v)); }

    private void showControlHud() {
        hudVisible = BotSettings.flag(this, "show_hud", true);
        controlHudView = new ControlHudView(this); controlHudView.setVisible(hudVisible);
        hudParams = new WindowManager.LayoutParams(-1, -1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        hudParams.gravity = Gravity.TOP | Gravity.START;
        try { windowManager.addView(controlHudView, hudParams); }
        catch (Exception e) { controlHudView = null; toast("HUD marker gagal tampil. Cek izin overlay."); }
    }

    private void showBubble() {
        TextView bubble = new TextView(this); bubble.setText("AI"); bubble.setTextColor(0xFF06140F);
        bubble.setTextSize(13); bubble.setTypeface(null,1); bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(round(0xFF4ADCC1,dp(28)));
        overlayParams = new WindowManager.LayoutParams(dp(56),dp(54),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START; overlayParams.x = dp(10); overlayParams.y = dp(175);
        overlayView = bubble; bubble.setOnTouchListener(this::handleBubbleTouch);
        try { windowManager.addView(overlayView,overlayParams); } catch(Exception e) { overlayView=null; toast("Bubble AI gagal tampil"); }
    }

    private boolean handleBubbleTouch(View v, MotionEvent e) {
        switch(e.getAction()) {
            case MotionEvent.ACTION_DOWN: downRawX=e.getRawX(); downRawY=e.getRawY(); startWindowX=overlayParams.x; startWindowY=overlayParams.y; dragging=false; return true;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getRawX()-downRawX, dy=e.getRawY()-downRawY;
                if(Math.abs(dx)+Math.abs(dy)>dp(7)) dragging=true;
                if(dragging) { overlayParams.x=startWindowX+Math.round(dx); overlayParams.y=startWindowY+Math.round(dy); try{windowManager.updateViewLayout(overlayView,overlayParams);}catch(Exception ignored){} }
                return true;
            case MotionEvent.ACTION_UP: if(!dragging) showPanel(); return true;
            default: return true;
        }
    }

    private void showPanel() {
        if (overlayView == null || expanded) return;
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12),dp(10),dp(12),dp(12)); panel.setBackground(round(0xF0182431,dp(16)));
        TextView title = new TextView(this); title.setText("AI CONTROLLER • v1.0.0"); title.setTextColor(0xFF4ADCC1); title.setTypeface(null,1); panel.addView(title);
        overlayStatus = new TextView(this); overlayStatus.setText(botEnabled ? "Bot aktif" : "Buka game lalu tekan RESUME BOT"); overlayStatus.setTextColor(0xFFFFFFFF); overlayStatus.setTextSize(11); overlayStatus.setPadding(0,dp(7),0,dp(6)); panel.addView(overlayStatus);
        overlayInfo = new TextView(this); overlayInfo.setText("SURVIVAL: menunggu game"); overlayInfo.setTextColor(0xFFB7C6D4); overlayInfo.setTextSize(10); panel.addView(overlayInfo);
        pauseButton = panelButton(botEnabled?"PAUSE BOT":"RESUME BOT"); panel.addView(pauseButton);
        pauseButton.setOnClickListener(v->{
            botEnabled=!botEnabled;
            pauseButton.setText(botEnabled?"PAUSE BOT":"RESUME BOT");
            if (controlHudView != null) controlHudView.setVisible(!botEnabled && hudVisible);
            updateOverlayStatus(botEnabled?"Bot dilanjutkan • titik bantuan disembunyikan":"Bot dijeda • titik bantuan ditampilkan");
        });
        Button editInGame = panelButton("EDIT LAYOUT LANGSUNG DI GAME"); panel.addView(editInGame);
        editInGame.setOnClickListener(v -> startInGameLayoutEditor());
        Button hud = panelButton(hudVisible?"SEMBUNYIKAN TITIK HUD":"TAMPILKAN TITIK HUD"); panel.addView(hud);
        hud.setOnClickListener(v->{hudVisible=!hudVisible;if(controlHudView!=null)controlHudView.setVisible(hudVisible);hud.setText(hudVisible?"SEMBUNYIKAN TITIK HUD":"TAMPILKAN TITIK HUD");});
        TextView tests = new TextView(this); tests.setText("UJI KONTROL MANUAL"); tests.setTextColor(0xFF9EDFD3); tests.setTextSize(10); tests.setPadding(0,dp(8),0,dp(2)); panel.addView(tests);
        addTestRow(panel, "jump", "LOMPAT", "sprint", "LARI");
        addTestRow(panel, "crouch", "JONGKOK", "prone", "TIARAP");
        addTestRow(panel, "interact", "INTERAKSI", "heal", "HEAL");
        addTestRow(panel, "gloo", "GLOO WALL", "crouch", "JONGKOK");
        Button cameraLeft = panelButton("KAMERA KIRI"); panel.addView(cameraLeft);
        cameraLeft.setOnClickListener(v -> GameInputAccessibilityService.panCamera(this, -0.18f, 0f, 450));
        Button cameraRight = panelButton("KAMERA KANAN"); panel.addView(cameraRight);
        cameraRight.setOnClickListener(v -> GameInputAccessibilityService.panCamera(this, 0.18f, 0f, 450));
        Button minimize = panelButton("MINIMIZE"); panel.addView(minimize); minimize.setOnClickListener(v->showBubbleAgain());
        Button stop = panelButton("STOP BOT & SCREEN READER"); panel.addView(stop); stop.setOnClickListener(v->stopSelf());
        ScrollView panelScroll = new ScrollView(this);
        panelScroll.setFillViewport(false);
        panelScroll.addView(panel);
        int panelHeight = Math.max(dp(220), Math.min(dp(560), getDisplayHeight() - dp(32)));
        replaceOverlay(panelScroll, dp(265), panelHeight); expanded=true;
    }

    private void startInGameLayoutEditor() {
        botEnabled = false;
        if (pauseButton != null) pauseButton.setText("RESUME BOT");
        if (controlHudView != null) controlHudView.setVisible(false);
        if (inGameLayoutEditor != null) inGameLayoutEditor.close();
        inGameLayoutEditor = new InGameLayoutEditor(this, windowManager, () -> {
            inGameLayoutEditor = null;
            if (controlHudView != null) controlHudView.setVisible(hudVisible);
            updateOverlayStatus("Tata letak game tersimpan • bot masih dijeda");
        });
        inGameLayoutEditor.show();
        showBubbleAgain();
    }

    private void addTestRow(LinearLayout parent, String firstKey, String firstLabel, String secondKey, String secondLabel) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button a = panelButton(firstLabel); Button b = panelButton(secondLabel);
        LinearLayout.LayoutParams pa = new LinearLayout.LayoutParams(0, dp(36), 1f); pa.rightMargin = dp(4);
        LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(0, dp(36), 1f); pb.leftMargin = dp(4);
        row.addView(a, pa); row.addView(b, pb); parent.addView(row);
        a.setOnClickListener(v -> { if (GameInputAccessibilityService.isReady()) GameInputAccessibilityService.tapControl(this, firstKey); });
        b.setOnClickListener(v -> { if (GameInputAccessibilityService.isReady()) GameInputAccessibilityService.tapControl(this, secondKey); });
    }

    private Button panelButton(String label) {
        Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setAllCaps(false);b.setTextColor(0xFFFFFFFF);b.setBackground(round(0xFF2A3A4C,dp(9)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(38));p.topMargin=dp(5);b.setLayoutParams(p);return b;
    }
    private void showBubbleAgain() { expanded=false; if(overlayView!=null){try{windowManager.removeView(overlayView);}catch(Exception ignored){}overlayView=null;} showBubble(); }
    private void replaceOverlay(View v,int w,int h) { try{if(overlayView!=null)windowManager.removeView(overlayView);overlayView=v;overlayParams.width=w;overlayParams.height=h;windowManager.addView(overlayView,overlayParams);}catch(Exception e){overlayView=null;stopSelf();} }
    private void updateOverlayStatus(String text) { new Handler(getMainLooper()).post(()->{if(overlayStatus!=null)overlayStatus.setText(text);}); }
    private void updateOverlayInfo(String text) { new Handler(getMainLooper()).post(()->{if(overlayInfo!=null)overlayInfo.setText(text);}); }
    private void createNotificationChannel() {
        if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Offline Survival Assistant",NotificationManager.IMPORTANCE_LOW);ch.setDescription("OCR lokal frame layar; tidak menyimpan video");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}
    }
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private String safeMessage(String s){return s==null?"unknown":s;}
    private void toast(String s){android.os.Handler h=new Handler(getMainLooper());h.post(()->android.widget.Toast.makeText(this,s,android.widget.Toast.LENGTH_LONG).show());}

    @Override public void onDestroy() {
        isStopping=true;
        previousSceneSample=null;
        if (mainHandler != null) mainHandler.removeCallbacksAndMessages(null);
        if (inGameLayoutEditor != null) { inGameLayoutEditor.close(); inGameLayoutEditor = null; }
        try{if(overlayView!=null)windowManager.removeView(overlayView);}catch(Exception ignored){}
        overlayView=null;overlayStatus=null;overlayInfo=null;
        try{if(controlHudView!=null)windowManager.removeView(controlHudView);}catch(Exception ignored){}
        controlHudView=null;
        try{if(virtualDisplay!=null)virtualDisplay.release();}catch(Exception ignored){}
        virtualDisplay=null;
        try{if(imageReader!=null)imageReader.close();}catch(Exception ignored){}
        imageReader=null;
        try{if(projection!=null)projection.stop();}catch(Exception ignored){}
        projection=null;
        if(frameThread!=null){frameThread.quitSafely();frameThread=null;}
        if(textRecognizer!=null){textRecognizer.close();textRecognizer=null;}
        if(analysisExecutor!=null){analysisExecutor.shutdown();analysisExecutor=null;}
        stopForeground(true);super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
