package com.fizz.aicontroller;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Small, individually touchable overlay handles. Empty screen areas are not
 * covered by a full-screen touch window, so the game remains usable while
 * the player drags each marker onto its matching in-game control.
 */
final class InGameLayoutEditor {
    interface Listener { void onClosed(); }

    private static final String[] IDS = {
            "move", "jump", "sprint", "crouch", "prone", "interact", "heal", "gloo",
            "camera", "hp_start", "hp_end"
    };
    private static final String[] LABELS = {
            "JOYSTICK", "LOMPAT", "LARI", "JONGKOK", "TIARAP", "INTERAKSI", "HEAL",
            "GLOO", "KAMERA", "HP AWAL", "HP AKHIR"
    };
    private static final int[] COLORS = {
            0xFF1C9C88, 0xFF2E8BDA, 0xFFE2A2A2, 0xFFBD8D35, 0xFF875BC0, 0xFF4D8E9C,
            0xFF4D9860, 0xFF2687C7, 0xFF8C63C7, 0xFFCA4D59, 0xFFCA4D59
    };

    private final Context context;
    private final WindowManager windowManager;
    private final Listener listener;
    private final List<View> markerViews = new ArrayList<>();
    private final List<String> markerIds = new ArrayList<>();
    private View toolbar;
    private WindowManager.LayoutParams toolbarParams;
    private boolean showing;

    InGameLayoutEditor(Context context, WindowManager windowManager, Listener listener) {
        this.context = context;
        this.windowManager = windowManager;
        this.listener = listener;
    }

    void show() {
        if (showing) return;
        showing = true;
        DisplayMetrics dm = screenMetrics();
        for (int i = 0; i < IDS.length; i++) addMarker(i, dm);
        addToolbar();
        Toast.makeText(context, "Geser setiap label tepat ke tengah tombol game, lalu SIMPAN", Toast.LENGTH_LONG).show();
    }

    boolean isShowing() { return showing; }

    private void addMarker(int index, DisplayMetrics dm) {
        final String id = IDS[index];
        TextView marker = new TextView(context);
        marker.setText(LABELS[index]);
        marker.setTextColor(Color.WHITE);
        marker.setTextSize(9.5f);
        marker.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        marker.setGravity(Gravity.CENTER);
        marker.setPadding(dp(4), dp(3), dp(4), dp(3));
        marker.setElevation(dp(8));
        marker.setBackground(pill(COLORS[index]));
        marker.setOnClickListener(v -> { /* performClick support for drag handle */ });

        int width = dp(index == 0 ? 82 : 72);
        int height = dp(42);
        WindowManager.LayoutParams lp = markerParams(width, height);
        int cx = Math.round((dm.widthPixels - 1) * BotSettings.xPercent(context, id) / 100f);
        int cy = Math.round((dm.heightPixels - 1) * BotSettings.yPercent(context, id) / 100f);
        lp.x = clamp(cx - width / 2, 0, Math.max(0, dm.widthPixels - width));
        lp.y = clamp(cy - height / 2, 0, Math.max(0, dm.heightPixels - height));

        marker.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        DisplayMetrics current = screenMetrics();
                        lp.x = clamp(startX + Math.round(event.getRawX() - downRawX), 0,
                                Math.max(0, current.widthPixels - lp.width));
                        lp.y = clamp(startY + Math.round(event.getRawY() - downRawY), 0,
                                Math.max(0, current.heightPixels - lp.height));
                        try { windowManager.updateViewLayout(v, lp); } catch (Exception ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                        saveMarker(id, v);
                        v.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return true;
                }
            }
        });

        try {
            windowManager.addView(marker, lp);
            markerViews.add(marker);
            markerIds.add(id);
        } catch (Exception e) {
            Toast.makeText(context, "Tidak bisa menampilkan titik " + LABELS[index], Toast.LENGTH_SHORT).show();
        }
    }

    private void addToolbar() {
        LinearLayout bar = new LinearLayout(context);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(4), dp(8), dp(4));
        bar.setBackground(roundRect(0xF01A2735, dp(12)));

        TextView info = new TextView(context);
        info.setText("EDIT HUD • GESER BAR INI");
        info.setTextColor(0xFF62E0C7);
        info.setTextSize(10);
        info.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(info, new LinearLayout.LayoutParams(0, dp(40), 1f));

        Button save = toolbarButton("SIMPAN");
        Button done = toolbarButton("SELESAI");
        bar.addView(save, new LinearLayout.LayoutParams(dp(82), dp(38)));
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(dp(82), dp(38));
        doneLp.leftMargin = dp(5);
        bar.addView(done, doneLp);
        save.setOnClickListener(v -> {
            saveAll();
            Toast.makeText(context, "Tata letak tersimpan", Toast.LENGTH_SHORT).show();
        });
        done.setOnClickListener(v -> close());

        WindowManager.LayoutParams lp = markerParams(dp(285), dp(50));
        DisplayMetrics dm = screenMetrics();
        lp.x = Math.max(dp(8), (dm.widthPixels - lp.width) / 2);
        lp.y = dp(8);
        toolbar = bar;
        toolbarParams = lp;
        info.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = toolbarParams.x; startY = toolbarParams.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        DisplayMetrics current = screenMetrics();
                        toolbarParams.x = clamp(startX + Math.round(event.getRawX() - downX), 0,
                                Math.max(0, current.widthPixels - toolbarParams.width));
                        toolbarParams.y = clamp(startY + Math.round(event.getRawY() - downY), 0,
                                Math.max(0, current.heightPixels - toolbarParams.height));
                        try { windowManager.updateViewLayout(toolbar, toolbarParams); } catch (Exception ignored) { }
                        return true;
                    default:
                        return true;
                }
            }
        });
        try { windowManager.addView(toolbar, lp); }
        catch (Exception e) {
            toolbar = null;
            Toast.makeText(context, "Toolbar editor gagal tampil", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveMarker(String id, View marker) {
        int[] location = new int[2];
        marker.getLocationOnScreen(location);
        DisplayMetrics dm = screenMetrics();
        float centerX = location[0] + marker.getWidth() / 2f;
        float centerY = location[1] + marker.getHeight() / 2f;
        float x = clampFloat(centerX / Math.max(1f, dm.widthPixels - 1) * 100f, 0f, 100f);
        float y = clampFloat(centerY / Math.max(1f, dm.heightPixels - 1) * 100f, 0f, 100f);
        BotSettings.prefs(context).edit()
                .putFloat("map_" + id + "_x", x)
                .putFloat("map_" + id + "_y", y)
                .putBoolean("layout_saved", true)
                .apply();
    }

    private void saveAll() {
        for (int i = 0; i < markerViews.size(); i++) {
            saveMarker(markerIds.get(i), markerViews.get(i));
        }
        BotSettings.prefs(context).edit().putBoolean("layout_saved", true).apply();
    }

    void close() {
        if (!showing) return;
        showing = false;
        for (View marker : markerViews) {
            try { windowManager.removeView(marker); } catch (Exception ignored) { }
        }
        markerViews.clear();
        markerIds.clear();
        toolbarParams = null;
        if (toolbar != null) {
            try { windowManager.removeView(toolbar); } catch (Exception ignored) { }
            toolbar = null;
        }
        if (listener != null) listener.onClosed();
    }

    private WindowManager.LayoutParams markerParams(int width, int height) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private DisplayMetrics screenMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    private Button toolbarButton(String text) {
        Button b = new Button(context);
        b.setText(text);
        b.setTextSize(9);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setBackground(roundRect(0xFF304658, dp(8)));
        return b;
    }

    private GradientDrawable pill(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor((color & 0x00FFFFFF) | 0xE0000000);
        d.setCornerRadius(dp(10));
        d.setStroke(dp(2), color);
        return d;
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), 0x6658DCC2);
        return d;
    }

    private int dp(float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private static float clampFloat(float value, float min, float max) { return Math.max(min, Math.min(max, value)); }
}
