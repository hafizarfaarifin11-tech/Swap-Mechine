package com.fizz.aicontroller;

import java.util.Locale;

/** Offline, rule-based HUD text interpretation. It does not identify people or game objects. */
final class LocalGameAnalyzer {
    static final int NONE = 0;
    static final int SPRINT = 1;
    static final int INTERACT = 2;
    static final int CROUCH = 3;
    static final int PRONE = 4;
    static final int HEAL = 5;

    static final class Advice {
        final int action;
        final String title;
        final String detail;
        Advice(int action, String title, String detail) {
            this.action = action;
            this.title = title;
            this.detail = detail;
        }
    }

    private LocalGameAnalyzer() { }

    static Advice analyze(String rawText) {
        String t = rawText == null ? "" : rawText.toUpperCase(Locale.ROOT)
                .replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) {
            return new Advice(NONE, "HUD belum terbaca", "Belum ada teks yang cukup jelas. Bot menunggu dan tidak menebak.");
        }
        if (containsAny(t, "SAFE ZONE SHRINK", "ZONE IS SHRINK", "ZONE SHRINKING", "OUTSIDE SAFE ZONE", "SAFE ZONE WILL")) {
            return new Advice(SPRINT, "Petunjuk zona terdeteksi", "Teks HUD mengarah ke perubahan zona. Saran: bergerak menuju area aman; tombol lari bisa dipakai jika sudah dipetakan.");
        }
        if (containsAny(t, "REVIVE", "RESCUE", "PICK UP", "PICKUP", "OPEN DOOR", "OPEN", "INTERACT")) {
            return new Advice(INTERACT, "Prompt interaksi terdeteksi", "Ada teks yang mungkin meminta interaksi. Periksa konteks sebelum mengaktifkan aksi otomatis.");
        }
        if (containsAny(t, "LOW HEALTH", "HEALTH CRITICAL", "HP LOW", "HEAL NOW", "USE MEDKIT")) {
            return new Advice(HEAL, "Petunjuk kondisi rendah terbaca", "Teks HUD mengarah ke kondisi kesehatan rendah. Periksa keadaan dulu; tombol heal bisa digunakan jika aksi otomatis diaktifkan.");
        }
        if (containsAny(t, "TAKE COVER", "GO PRONE", "GET DOWN")) {
            return new Advice(PRONE, "Petunjuk berlindung terbaca", "Teks HUD meminta posisi rendah. Tombol tiarap dapat dipakai jika titik kontrol sudah benar.");
        }
        if (containsAny(t, "ENEMY NEAR", "DANGER NEAR", "DANGER")) {
            return new Advice(CROUCH, "Peringatan situasi terbaca", "HUD memuat peringatan. Saran: berhenti sejenak dan pertimbangkan posisi jongkok; bot tidak menebak lokasi objek.");
        }
        String excerpt = t.length() > 100 ? t.substring(0, 100) + "…" : t;
        return new Advice(NONE, "HUD berhasil dibaca", "Teks: " + excerpt + ". Belum ada aturan lokal yang cocok, jadi bot tidak menjalankan aksi otomatis.");
    }

    private static boolean containsAny(String text, String... tokens) {
        for (String token : tokens) if (text.contains(token)) return true;
        return false;
    }
}
