package com.fizz.aicontroller;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String BHOP_PACKAGE = "com.begma.bhoppro";
    private TextView permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF0B1016);
        getWindow().setNavigationBarColor(0xFF0B1016);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionStatus();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFF0B1016);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(content);

        TextView eyebrow = text("OFFLINE GAME COACH  •  v0.3", 11, 0xFF36D6B0, true);
        eyebrow.setLetterSpacing(0.12f);
        content.addView(eyebrow);

        TextView title = text("AI Controller", 31, 0xFFFFFFFF, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(8);
        content.addView(title, titleParams);

        TextView subtitle = text(
                "Bhop Pro Coach memberi saran latihan dan sorotan visual untuk menunjukkan lokasi tombol loncat. Tidak membaca layar, tidak merekam, dan tidak mengendalikan game.",
                15, 0xFFB7C2CC, false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(8);
        content.addView(subtitle, subtitleParams);

        LinearLayout profileCard = card();
        addTopMargin(content, profileCard, 22);
        profileCard.addView(text("PROFIL GAME AKTIF", 10, 0xFF36D6B0, true));
        TextView profile = text("Bhop Pro", 21, 0xFFFFFFFF, true);
        LinearLayout.LayoutParams profileParams = new LinearLayout.LayoutParams(-1, -2);
        profileParams.topMargin = dp(5);
        profileCard.addView(profile, profileParams);
        TextView profileNote = text("FPS / Bunny Hop • panduan manual offline", 13, 0xFFB7C2CC, false);
        LinearLayout.LayoutParams profileNoteParams = new LinearLayout.LayoutParams(-1, -2);
        profileNoteParams.topMargin = dp(4);
        profileCard.addView(profileNote, profileNoteParams);

        LinearLayout privacyCard = card();
        addTopMargin(content, privacyCard, 12);
        privacyCard.addView(text("PRIVASI & PERFORMA", 15, 0xFFFFFFFF, true));
        addCardLine(privacyCard, "• Fitur tangkapan layar tidak digunakan.");
        addCardLine(privacyCard, "• Tidak ada screen capture, OCR, atau rekaman.");
        addCardLine(privacyCard, "• Tidak ada API key, internet, atau model AI besar.");
        addCardLine(privacyCard, "• Spotlight hanya menggambar lapisan gelap dan lingkaran transparan.");
        addCardLine(privacyCard, "• Posisi tombol loncat diatur manual dan disimpan di perangkat.");

        LinearLayout howCard = card();
        addTopMargin(content, howCard, 12);
        howCard.addView(text("CARA PAKAI", 15, 0xFFFFFFFF, true));
        addCardLine(howCard, "1. Izinkan tampil di atas aplikasi lain.");
        addCardLine(howCard, "2. Mulai Bhop Pro Coach untuk menampilkan bubble.");
        addCardLine(howCard, "3. Buka Bhop Pro, ketuk bubble BHOP, lalu pilih Tunjukkan Tombol Loncat.");
        addCardLine(howCard, "4. Pertama kali, ketuk atau geser lingkaran ke tombol loncat, lalu pilih Simpan Posisi.");
        addCardLine(howCard, "5. Layar akan diredupkan kecuali area tombol loncat. Ketuk layar untuk menutup sorotan.");

        permissionStatus = text("Memeriksa izin overlay...", 13, 0xFFB7C2CC, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(20);
        content.addView(permissionStatus, statusParams);

        Button permissionButton = makeButton("1. AKTIFKAN IZIN OVERLAY");
        addTopMargin(content, permissionButton, 10);
        permissionButton.setOnClickListener(v -> requestOverlayPermission());

        Button startButton = makeButton("2. MULAI BHOP PRO COACH");
        addTopMargin(content, startButton, 10);
        startButton.setOnClickListener(v -> startCoach());

        Button openGameButton = makeButton("BUKA BHOP PRO");
        addTopMargin(content, openGameButton, 10);
        openGameButton.setBackground(roundBackground(0xFF26313D, dp(14)));
        openGameButton.setTextColor(0xFFFFFFFF);
        openGameButton.setOnClickListener(v -> openBhopPro());

        Button stopButton = makeButton("HENTIKAN COACH");
        addTopMargin(content, stopButton, 10);
        stopButton.setBackground(roundBackground(0xFF26313D, dp(14)));
        stopButton.setTextColor(0xFFFFFFFF);
        stopButton.setOnClickListener(v -> {
            stopService(new Intent(this, AIOverlayService.class));
            Toast.makeText(this, "Bhop Pro Coach dihentikan", Toast.LENGTH_SHORT).show();
        });

        TextView footer = text("AI Controller v0.3.0  •  Bhop Pro Spotlight  •  No screen capture", 11, 0xFF71808F, false);
        footer.setGravity(Gravity.CENTER);
        addTopMargin(content, footer, 22);
        setContentView(scroll);
    }

    private void startCoach() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin overlay terlebih dahulu", Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }
        Intent intent = new Intent(this, AIOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        Toast.makeText(this, "Bhop Pro Coach aktif. Bubble BHOP sudah siap.", Toast.LENGTH_LONG).show();
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show();
        }
    }

    private void openBhopPro() {
        PackageManager pm = getPackageManager();
        Intent launch = pm.getLaunchIntentForPackage(BHOP_PACKAGE);
        if (launch == null) {
            Toast.makeText(this, "Bhop Pro belum ditemukan. Pasang game terlebih dahulu.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivity(launch);
        } catch (Exception exception) {
            Toast.makeText(this, "Tidak bisa membuka Bhop Pro dari sini.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshPermissionStatus() {
        if (permissionStatus == null) return;
        boolean allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        permissionStatus.setText(allowed
                ? "Status izin: overlay sudah diizinkan."
                : "Status izin: overlay belum diizinkan.");
        permissionStatus.setTextColor(allowed ? 0xFF36D6B0 : 0xFFFFC078);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(roundBackground(0xFF151D27, dp(18)));
        return box;
    }

    private void addCardLine(LinearLayout card, String value) {
        TextView line = text(value, 13, 0xFFD0D6DC, false);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        card.addView(line, params);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        view.setLineSpacing(dp(3), 1.0f);
        return view;
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(13);
        button.setTextColor(0xFF07120F);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(52));
        button.setBackground(roundBackground(0xFF36D6B0, dp(14)));
        return button;
    }

    private void addTopMargin(LinearLayout parent, View child, int marginDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(marginDp);
        parent.addView(child, params);
    }

    private android.graphics.drawable.GradientDrawable roundBackground(int color, int radius) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
