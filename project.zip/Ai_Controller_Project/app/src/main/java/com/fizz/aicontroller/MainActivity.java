package com.fizz.aicontroller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 6101;
    private TextView status;
    private Spinner strategy;
    private CheckBox autoActions, autoHop, showHud;
    private SeekBar frameInterval, hopInterval;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 88);
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(0xFF0A111A);
        scroll.addView(root);
        root.addView(text("FIZZ LABS  /  OFFLINE GAME EXPERIMENT", 10, 0xFF4ADCC1, true));
        add(root, text("AI CONTROLLER", 28, 0xFFFFFFFF, true), 5);
        add(root, text("v0.7.0 • HUD Layout + Offline Screen Reader", 12, 0xFF9BAAB9, false), 3);

        LinearLayout intro = card(); add(root, intro, 16);
        intro.addView(text("APA YANG BERUBAH", 14, 0xFF4ADCC1, true));
        add(intro, text("Sekarang ada editor tata letak visual. Geser label JOYSTICK, LOMPAT, LARI, JONGKOK, TIARAP, INTERAKSI, dan HEAL ke posisi tombol HUD game. Saat bot berjalan, posisi itu ditampilkan sebagai lingkaran HUD transparan.", 12, 0xFFD7E0E9, false), 7);
        add(intro, text("Screen capture mengambil frame sesekali, bukan menyimpan video. ML Kit Text Recognition dibundel di APK agar OCR bisa offline. Analisisnya membaca teks HUD dan menjalankan aturan sederhana; belum mengenali karakter, musuh, atau rintangan seperti pemain manusia.", 11, 0xFFFFC87A, false), 7);

        LinearLayout permissions = card(); add(root, permissions, 12);
        permissions.addView(text("PERIZINAN", 14, ColorWhite(), true));
        status = text("Memeriksa izin…", 12, 0xFFBEC9D4, false); add(permissions, status, 8);
        Button overlay = button("IZINKAN FLOATING OVERLAY"); add(permissions, overlay, 7);
        overlay.setOnClickListener(v -> requestOverlay());
        Button accessibility = buttonSecondary("AKTIFKAN GAME INPUT ACCESSIBILITY"); add(permissions, accessibility, 7);
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        LinearLayout layout = card(); add(root, layout, 12);
        layout.addView(text("1. CONTROL LAYOUT EDITOR", 14, 0xFFFFFFFF, true));
        add(layout, text("Atur posisi tombol sekali. Gunakan game dalam orientasi landscape agar koordinatnya cocok. Layout bisa diubah lagi kapan pun.", 11, 0xFF9BAAB9, false), 6);
        Button edit = button("BUKA EDITOR TATA LETAK HUD"); add(layout, edit, 8);
        edit.setOnClickListener(v -> startActivity(new Intent(this, ControlLayoutActivity.class)));
        add(layout, text("Legenda titik HUD: 1 Joystick • 2 Lompat • 3 Lari • 4 Jongkok • 5 Tiarap • 6 Interaksi • 7 Heal", 10, 0xFF9BAAB9, false), 7);
        Button testJump = buttonSecondary("UJI TITIK TOMBOL LOMPAT"); add(layout, testJump, 7);
        testJump.setOnClickListener(v -> testMapped("jump"));

        LinearLayout vision = card(); add(root, vision, 12);
        vision.addView(text("2. OFFLINE SCREEN READER", 14, 0xFFFFFFFF, true));
        add(vision, text("Mode analisis", 11, 0xFF9BAAB9, false), 7);
        strategy = new Spinner(this);
        String[] modes = {"Baca teks HUD + saran lokal", "Ikuti marker warna", "Maju + lompat berkala", "Zig-zag + lompat"};
        strategy.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        vision.addView(strategy, new LinearLayout.LayoutParams(-1, dp(48)));
        autoActions = check("Aksi otomatis dari teks HUD (lari / interaksi)"); add(vision, autoActions, 6);
        autoHop = check("Lompat berkala saat mode gerakan aktif"); add(vision, autoHop, 2);
        showHud = check("Tampilkan titik HUD di atas game"); add(vision, showHud, 2);
        add(vision, text("Frekuensi pembacaan layar", 11, 0xFF9BAAB9, false), 7);
        frameInterval = new SeekBar(this); frameInterval.setMax(5); frameInterval.setProgress(2);
        vision.addView(frameInterval, new LinearLayout.LayoutParams(-1, dp(40)));
        add(vision, text("Sekitar 0,4–1 frame/detik pada resolusi analisis maksimal 640 px. Default dibuat pelan agar lebih ringan untuk RAM 4 GB.", 10, 0xFF8292A3, false), 1);
        add(vision, text("Interval lompat", 11, 0xFF9BAAB9, false), 7);
        hopInterval = new SeekBar(this); hopInterval.setMax(24); hopInterval.setProgress(10);
        vision.addView(hopInterval, new LinearLayout.LayoutParams(-1, dp(40)));

        Button save = button("SIMPAN PENGATURAN"); add(root, save, 12);
        save.setOnClickListener(v -> saveSettings());
        Button start = button("3. MULAI SCREEN READER + HUD"); add(root, start, 8);
        start.setOnClickListener(v -> startCapture());
        Button stop = buttonSecondary("HENTIKAN BOT & SCREEN CAPTURE"); add(root, stop, 8);
        stop.setOnClickListener(v -> stopService(new Intent(this, CaptureBotService.class)));

        TextView footer = text("Privasi: frame diproses lokal di memori, tidak disimpan sebagai video dan tidak dikirim ke server. Android tetap menampilkan indikator screen capture. Aksesibilitas hanya dipakai untuk gesture tombol yang kamu petakan.", 10, 0xFF748394, false);
        footer.setGravity(Gravity.CENTER); add(root, footer, 16);
        setContentView(scroll); loadSettings(); refreshStatus();
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } else Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show();
    }

    private boolean inputEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = getPackageName() + "/" + GameInputAccessibilityService.class.getName();
        return enabled.toLowerCase().contains(target.toLowerCase());
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        status.setText("Overlay: " + (overlay ? "AKTIF" : "BELUM") + "   •   Accessibility: " + (inputEnabled() ? "AKTIF" : "BELUM")
                + "   •   Layout: " + (BotSettings.flag(this, "layout_saved", false) ? "TERSIMPAN" : "DEFAULT"));
    }

    private void startCapture() {
        if (!saveSettings()) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan floating overlay dulu", Toast.LENGTH_LONG).show(); requestOverlay(); return;
        }
        if (!inputEnabled()) {
            Toast.makeText(this, "Aktifkan Game Input Accessibility dulu", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, CaptureBotService.class);
                service.putExtra(CaptureBotService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(CaptureBotService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
                Toast.makeText(this, "Screen reader aktif. Buka game untuk melihat HUD AI.", Toast.LENGTH_LONG).show();
            } else Toast.makeText(this, "Izin screen capture dibatalkan", Toast.LENGTH_SHORT).show();
        }
    }

    private void testMapped(String control) {
        if (!inputEnabled()) { Toast.makeText(this, "Aktifkan Accessibility dulu", Toast.LENGTH_LONG).show(); startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
        GameInputAccessibilityService.tapControl(this, control);
        Toast.makeText(this, "Tap uji dikirim ke posisi " + control.toUpperCase(), Toast.LENGTH_SHORT).show();
    }

    private boolean saveSettings() {
        BotSettings.prefs(this).edit()
                .putInt("strategy", strategy.getSelectedItemPosition())
                .putBoolean("auto_hud_actions", autoActions.isChecked())
                .putBoolean("auto_hop", autoHop.isChecked())
                .putBoolean("show_hud", showHud.isChecked())
                .putInt("frame_interval", 2500 - frameInterval.getProgress() * 300)
                .putInt("hop_interval", 800 + hopInterval.getProgress() * 100)
                .apply();
        Toast.makeText(this, "Pengaturan tersimpan", Toast.LENGTH_SHORT).show(); refreshStatus(); return true;
    }

    private void loadSettings() {
        strategy.setSelection(Math.max(0, Math.min(3, BotSettings.integer(this, "strategy", 0))));
        autoActions.setChecked(BotSettings.flag(this, "auto_hud_actions", false));
        autoHop.setChecked(BotSettings.flag(this, "auto_hop", true));
        showHud.setChecked(BotSettings.flag(this, "show_hud", true));
        int interval = BotSettings.integer(this, "frame_interval", 1900);
        frameInterval.setProgress(Math.max(0, Math.min(5, (2500 - interval) / 300)));
        int hop = BotSettings.integer(this, "hop_interval", 1800);
        hopInterval.setProgress(Math.max(0, Math.min(24, (hop - 800) / 100)));
    }

    private CheckBox check(String label) { CheckBox c = new CheckBox(this); c.setText(label); c.setTextColor(0xFFD7E0E9); c.setTextSize(12); return c; }
    private LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(14),dp(14),dp(14)); l.setBackground(round(0xFF151F2B,dp(16))); return l; }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setAllCaps(false); b.setTypeface(null,1); b.setTextColor(0xFF07120F); b.setBackground(round(0xFF4ADCC1,dp(10))); b.setMinHeight(dp(48)); return b; }
    private Button buttonSecondary(String label) { Button b=button(label); b.setBackground(round(0xFF293747,dp(10))); b.setTextColor(0xFFFFFFFF); return b; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,1); t.setLineSpacing(dp(3),1f); return t; }
    private void add(LinearLayout p, View v, int top) { LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(top); p.addView(v,lp); }
    private android.graphics.drawable.GradientDrawable round(int color,int radius) { android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private int ColorWhite() { return 0xFFFFFFFF; }
}
