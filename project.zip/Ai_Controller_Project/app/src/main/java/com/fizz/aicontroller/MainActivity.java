package com.fizz.aicontroller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 6101;
    private static final int REQUEST_OVERLAY = 6102;
    private EditText moveX, moveY, moveRadius, jumpX, jumpY;
    private Spinner cueColor, strategy;
    private SeekBar sensitivity, hopInterval;
    private CheckBox autoHop;
    private TextView permissionStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 88);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        refreshPermissionStatus();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(26));
        root.setBackgroundColor(0xFF0B1016);
        scroll.addView(root);

        root.addView(text("FIZZ LABS  /  OFFLINE GAME EXPERIMENT", 10, 0xFF36D6B0, true));
        addTop(root, text("AI CONTROLLER", 28, 0xFFFFFFFF, true), 6);
        addTop(root, text("v0.6.0 • Local vision + movement coach", 12, 0xFF9EABB8, false), 4);

        LinearLayout intro = card();
        addTop(root, intro, 18);
        intro.addView(text("MOVEMENT AUTOPILOT", 14, 0xFF36D6B0, true));
        addTop(intro, text("Bot membaca frame beresolusi rendah di memori, mencari marker navigasi berwarna yang kamu pilih, lalu mengarahkan joystick virtual ke posisi marker. Jika Auto Hop aktif, bot akan menekan tombol lompat secara berkala saat marker terlihat.", 12, 0xFFD6DCE2, false), 8);
        addTop(intro, text("Ini prototipe vision ringan berbasis warna, bukan model neural network yang memahami semua objek game. Marker harus terlihat jelas dan konsisten. Tidak ada bidik, tembak, atau aksi senjata.", 11, 0xFFFFC078, false), 8);

        LinearLayout permissions = card();
        addTop(root, permissions, 12);
        permissions.addView(text("PERMISSIONS", 15, 0xFFFFFFFF, true));
        permissionStatus = text("Memeriksa izin…", 12, 0xFFB7C2CC, false);
        addTop(permissions, permissionStatus, 8);
        Button overlay = button("1. IZINKAN FLOATING OVERLAY");
        addTop(permissions, overlay, 8);
        overlay.setOnClickListener(v -> requestOverlayPermission());
        Button accessibility = button("2. AKTIFKAN GAME INPUT ACCESSIBILITY");
        addTop(permissions, accessibility, 8);
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        LinearLayout mapping = card();
        addTop(root, mapping, 12);
        mapping.addView(text("CONTROL MAPPING", 15, 0xFFFFFFFF, true));
        addTop(mapping, text("Atur koordinat sebagai persen layar (0–100). Untuk joystick gerak, isi titik tengah area joystick. Radius menentukan jarak dorong ke arah yang dipilih. Atur saat game dalam landscape.", 11, 0xFF9EABB8, false), 6);
        LinearLayout moveRow = row();
        moveRow.addView(fieldColumn("JOYSTICK X %", moveX = field("12")), weighted());
        moveRow.addView(fieldColumn("JOYSTICK Y %", moveY = field("78")), weighted());
        addTop(mapping, moveRow, 8);
        LinearLayout radiusRow = row();
        radiusRow.addView(fieldColumn("JOYSTICK RADIUS %", moveRadius = field("9")), weighted());
        radiusRow.addView(fieldColumn("JUMP X %", jumpX = field("91")), weighted());
        radiusRow.addView(fieldColumn("JUMP Y %", jumpY = field("82")), weighted());
        addTop(mapping, radiusRow, 8);

        LinearLayout vision = card();
        addTop(root, vision, 12);
        vision.addView(text("LOCAL VISION", 15, 0xFFFFFFFF, true));
        addTop(vision, text("Pilih warna marker navigasi yang tampak di game atau arena tes.", 11, 0xFF9EABB8, false), 8);
        addTop(vision, text("Mode gerakan", 11, 0xFF9EABB8, false), 5);
        strategy = new Spinner(this);
        String[] modes = {"Ikuti marker visual", "Maju + hop berkala", "Zig-zag + hop"};
        ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes);
        strategy.setAdapter(modeAdapter);
        vision.addView(strategy, new LinearLayout.LayoutParams(-1, dp(48)));
        addTop(vision, text("Warna marker (dipakai pada mode Ikuti marker)", 11, 0xFF9EABB8, false), 7);
        cueColor = new Spinner(this);
        String[] colors = {"Merah", "Hijau", "Biru", "Kuning"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, colors);
        cueColor.setAdapter(adapter);
        vision.addView(cueColor, new LinearLayout.LayoutParams(-1, dp(48)));
        addTop(vision, text("Sensitivitas warna", 11, 0xFF9EABB8, false), 8);
        sensitivity = new SeekBar(this);
        sensitivity.setMax(50);
        sensitivity.setProgress(25);
        vision.addView(sensitivity, new LinearLayout.LayoutParams(-1, dp(40)));
        autoHop = new CheckBox(this);
        autoHop.setText("AUTO HOP saat marker terlihat");
        autoHop.setTextColor(0xFFD6DCE2);
        autoHop.setTextSize(12);
        autoHop.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFF36D6B0));
        vision.addView(autoHop);
        addTop(vision, text("Interval lompatan", 11, 0xFF9EABB8, false), 6);
        hopInterval = new SeekBar(this);
        hopInterval.setMax(25);
        hopInterval.setProgress(10);
        vision.addView(hopInterval, new LinearLayout.LayoutParams(-1, dp(40)));
        addTop(vision, text("Rentang: 800 ms hingga 3.300 ms. Semakin kecil, semakin sering melompat.", 10, 0xFF8493A2, false), 2);

        Button save = button("SIMPAN MAPPING & VISION");
        addTop(root, save, 14);
        save.setOnClickListener(v -> saveSettings());
        Button testJump = buttonSecondary("UJI TOMBOL LOMPAT");
        addTop(root, testJump, 8);
        testJump.setOnClickListener(v -> testJump());
        Button start = button("3. MULAI BOT • IZINKAN SCREEN CAPTURE");
        addTop(root, start, 10);
        start.setOnClickListener(v -> startBotFlow());
        Button stop = buttonSecondary("HENTIKAN BOT");
        addTop(root, stop, 8);
        stop.setOnClickListener(v -> stopService(new Intent(this, CaptureBotService.class)));

        TextView footer = text("Frame diperkecil dan dianalisis lokal di memori; tidak ada video atau screenshot yang disimpan dan tidak ada internet/API key. Android tetap menampilkan indikator dan notifikasi Screen Capture saat sesi aktif.", 10, 0xFF778594, false);
        footer.setGravity(Gravity.CENTER);
        addTop(root, footer, 18);
        setContentView(scroll);
        loadSettings();
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY);
        } else refreshPermissionStatus();
    }

    private boolean isInputServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = getPackageName() + "/" + GameInputAccessibilityService.class.getName();
        return enabled.toLowerCase().contains(target.toLowerCase());
    }

    private void refreshPermissionStatus() {
        if (permissionStatus == null) return;
        boolean overlay = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        boolean access = isInputServiceEnabled();
        permissionStatus.setText("Overlay: " + (overlay ? "AKTIF" : "BELUM") + "   •   Gesture: " + (access ? "AKTIF" : "BELUM"));
    }

    private void startBotFlow() {
        if (!saveSettings()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan overlay dulu", Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }
        if (!isInputServiceEnabled()) {
            Toast.makeText(this, "Aktifkan Game Input Accessibility dulu", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private void testJump() {
        if (!isInputServiceEnabled()) {
            Toast.makeText(this, "Aktifkan Accessibility dulu", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        try {
            int x = Math.round(getResources().getDisplayMetrics().widthPixels * percent(jumpX) / 100f);
            int y = Math.round(getResources().getDisplayMetrics().heightPixels * percent(jumpY) / 100f);
            GameInputAccessibilityService.tap(x, y, 80);
            Toast.makeText(this, "Gesture lompat dikirim. Cek koordinat jika tidak tepat.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Koordinat lompat belum valid", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            refreshPermissionStatus();
        } else if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, CaptureBotService.class);
                service.putExtra(CaptureBotService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(CaptureBotService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                else startService(service);
                Toast.makeText(this, "Vision bot aktif. Buka game dan gunakan panel BOT.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Izin Screen Capture dibatalkan", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean saveSettings() {
        try {
            float mx = percent(moveX), my = percent(moveY), radius = percent(moveRadius);
            float jx = percent(jumpX), jy = percent(jumpY);
            if (radius < 2 || radius > 25) throw new IllegalArgumentException("Radius joystick harus 2–25%.");
            BotSettings.prefs(this).edit()
                    .putFloat("move_x", mx).putFloat("move_y", my)
                    .putFloat("move_radius", radius)
                    .putFloat("jump_x", jx).putFloat("jump_y", jy)
                    .putInt("cue_color", cueColor.getSelectedItemPosition())
                    .putInt("strategy", strategy.getSelectedItemPosition())
                    .putInt("sensitivity", sensitivity.getProgress())
                    .putBoolean("auto_hop", autoHop.isChecked())
                    .putInt("hop_interval", 800 + hopInterval.getProgress() * 100)
                    .apply();
            Toast.makeText(this, "Mapping dan vision tersimpan", Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage() == null ? "Periksa koordinat" : e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void loadSettings() {
        moveX.setText(String.valueOf(BotSettings.value(this, "move_x", 12f)));
        moveY.setText(String.valueOf(BotSettings.value(this, "move_y", 78f)));
        moveRadius.setText(String.valueOf(BotSettings.value(this, "move_radius", 9f)));
        jumpX.setText(String.valueOf(BotSettings.value(this, "jump_x", 91f)));
        jumpY.setText(String.valueOf(BotSettings.value(this, "jump_y", 82f)));
        cueColor.setSelection(BotSettings.integer(this, "cue_color", 0));
        strategy.setSelection(BotSettings.integer(this, "strategy", 0));
        sensitivity.setProgress(BotSettings.integer(this, "sensitivity", 25));
        autoHop.setChecked(BotSettings.flag(this, "auto_hop", true));
        int interval = BotSettings.integer(this, "hop_interval", 1800);
        hopInterval.setProgress(Math.max(0, Math.min(25, (interval - 800) / 100)));
    }

    private float percent(EditText field) {
        float value = Float.parseFloat(field.getText().toString().trim());
        if (value < 0 || value > 100) throw new IllegalArgumentException("Semua koordinat harus 0–100%.");
        return value;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(15), dp(15), dp(15));
        box.setBackground(round(0xFF151D27, dp(16)));
        return box;
    }
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }
    private LinearLayout fieldColumn(String label, EditText edit) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(label, 10, 0xFF9EABB8, true));
        col.addView(edit);
        return col;
    }
    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.rightMargin = dp(7);
        return p;
    }
    private EditText field(String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(value);
        e.setTextColor(0xFFFFFFFF);
        e.setHintTextColor(0xFF7E8A97);
        e.setInputType(8194);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(round(0xFF202B38, dp(9)));
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(44)));
        return e;
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(12); b.setAllCaps(false);
        b.setTextColor(0xFF07120F); b.setTypeface(null, 1);
        b.setBackground(round(0xFF36D6B0, dp(12))); b.setMinHeight(dp(50));
        return b;
    }
    private Button buttonSecondary(String label) {
        Button b = button(label);
        b.setBackground(round(0xFF26313D, dp(12)));
        b.setTextColor(0xFFFFFFFF);
        return b;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        t.setLineSpacing(dp(3), 1f);
        return t;
    }
    private void addTop(LinearLayout parent, View child, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(margin);
        parent.addView(child, p);
    }
    private android.graphics.drawable.GradientDrawable round(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
