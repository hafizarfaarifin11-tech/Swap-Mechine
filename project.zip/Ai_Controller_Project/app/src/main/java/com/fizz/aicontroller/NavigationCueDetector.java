package com.fizz.aicontroller;

import android.graphics.Bitmap;
import android.graphics.Color;

/** Lightweight local color-cue detector. This tracks a configured navigation cue, not game characters. */
final class NavigationCueDetector {
    static final class Cue {
        final float centerX;
        final float centerY;
        final int area;
        final int width;
        final int height;
        Cue(float x, float y, int area, int width, int height) {
            this.centerX = x; this.centerY = y; this.area = area; this.width = width; this.height = height;
        }
    }
    private NavigationCueDetector() { }

    static Cue detect(Bitmap bitmap, int colorMode, int sensitivity) {
        if (bitmap == null) return null;
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int count = w * h;
        int[] pixels = new int[count];
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
        byte[] mask = new byte[count];
        boolean[] seen = new boolean[count];
        float[] hsv = new float[3];
        int left = (int) (w * 0.06f), right = (int) (w * 0.94f);
        int top = (int) (h * 0.10f), bottom = (int) (h * 0.88f);
        int satMin = Math.max(75, 155 - sensitivity * 2);
        int valMin = Math.max(65, 135 - sensitivity);
        for (int y = top; y < bottom; y++) {
            int row = y * w;
            for (int x = left; x < right; x++) {
                Color.colorToHSV(pixels[row + x], hsv);
                int sat = (int) (hsv[1] * 255f), val = (int) (hsv[2] * 255f);
                if (sat >= satMin && val >= valMin && matches(hsv[0], colorMode)) mask[row + x] = 1;
            }
        }
        int[] queue = new int[count];
        int bestArea = 0, bestMinX = 0, bestMaxX = 0, bestMinY = 0, bestMaxY = 0;
        long bestSumX = 0, bestSumY = 0;
        for (int y = top; y < bottom; y++) {
            for (int x = left; x < right; x++) {
                int start = y * w + x;
                if (mask[start] == 0 || seen[start]) continue;
                int head = 0, tail = 0;
                queue[tail++] = start; seen[start] = true;
                int area = 0, minX = x, maxX = x, minY = y, maxY = y;
                long sumX = 0, sumY = 0;
                while (head < tail) {
                    int index = queue[head++];
                    int px = index % w, py = index / w;
                    area++; sumX += px; sumY += py;
                    if (px < minX) minX = px; if (px > maxX) maxX = px;
                    if (py < minY) minY = py; if (py > maxY) maxY = py;
                    if (px > left) tail = add(index - 1, mask, seen, queue, tail);
                    if (px + 1 < right) tail = add(index + 1, mask, seen, queue, tail);
                    if (py > top) tail = add(index - w, mask, seen, queue, tail);
                    if (py + 1 < bottom) tail = add(index + w, mask, seen, queue, tail);
                }
                int bw = maxX - minX + 1, bh = maxY - minY + 1;
                if (area >= 8 && area <= (w * h) / 6 && bw >= 3 && bh >= 3 && area > bestArea) {
                    bestArea = area; bestMinX = minX; bestMaxX = maxX;
                    bestMinY = minY; bestMaxY = maxY; bestSumX = sumX; bestSumY = sumY;
                }
            }
        }
        if (bestArea == 0) return null;
        return new Cue((bestSumX / (float) bestArea) / w,
                (bestSumY / (float) bestArea) / h,
                bestArea, bestMaxX - bestMinX + 1, bestMaxY - bestMinY + 1);
    }

    private static int add(int index, byte[] mask, boolean[] seen, int[] queue, int tail) {
        if (mask[index] != 0 && !seen[index]) { seen[index] = true; queue[tail++] = index; }
        return tail;
    }
    private static boolean matches(float hue, int mode) {
        switch (mode) {
            case 1: return hue >= 82 && hue <= 158;  // green
            case 2: return hue >= 185 && hue <= 255; // blue
            case 3: return hue >= 38 && hue <= 78;   // yellow
            default: return hue <= 18 || hue >= 342; // red
        }
    }
}
