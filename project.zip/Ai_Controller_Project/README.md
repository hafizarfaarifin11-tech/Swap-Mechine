# AI Controller Offline Movement Bot v0.6.0

Android prototype for a user-owned offline or sandbox game. The v0.6 build focuses on local visual cue following and movement/jump input only. It intentionally does not automate aiming, firing, weapons, or combat actions.

## What it does

- Requests explicit Android MediaProjection permission and receives a low-resolution display stream.
- Processes frames locally in memory at about 1.5 frames/second. No screenshots or video are written to storage and no network/API key is used.
- Detects the largest connected region matching a user-selected red, green, blue, or yellow navigation cue.
- Smooths cue coordinates and uses a dead-zone plus hysteresis-like damping to reduce jitter.
- Maps a virtual movement joystick center and radius, then dispatches short directional swipes through an explicitly enabled Accessibility Service.
- Optionally taps the configured Jump control on a user-selected interval while the cue is visible.
- Stops issuing input when the cue is not found for a short timeout; this is a fail-safe, not an intelligent obstacle detector.
- Provides a draggable floating AI panel with pause/resume and stop controls.

## Honest limitations

This is lightweight computer vision based on color segmentation and connected components, not a trained neural network. Follow Marker mode does not recognize enemies, terrain, obstacles, safe zones, or semantic game events. A matching bright HUD element/effect can be mistaken for the navigation cue. For the follow-cue behavior to work, the game or test scene needs a distinctive, visible marker of the chosen color. If no such marker exists, use one of the basic movement-pattern modes or the bot will wait rather than guessing. Forward and zig-zag modes are timed movement patterns, not obstacle-aware navigation.

The movement gesture is a short joystick drag, not a continuous native game controller signal. Timing and response differ by game and device. Calibrate the joystick center/radius and jump coordinate in landscape before running. The Test Jump button sends one explicit tap so you can validate the jump coordinate.

## Setup

1. Install the debug APK built by GitHub Actions.
2. Open AI Controller and allow floating overlay.
3. Enable **AI Controller Game Input** under Android Accessibility settings. This service can dispatch gestures; Android requires explicit user activation.
4. Set movement joystick center X/Y, joystick radius, and Jump X/Y as screen percentages (0–100).
5. Choose the color of a distinct navigation marker and set sensitivity. Enable/disable Auto Hop and set its interval.
6. Save, use **Test Jump** to verify the jump coordinate, then press Start and approve the Android screen-capture prompt.
7. Open the offline/sandbox game. Tap the floating AI bubble to view status, pause, resume, or stop.

## Privacy and performance

The capture stream is downscaled to a maximum dimension of about 480 pixels and sampled approximately every 650 ms. Image buffers are processed in memory and discarded; no persistent recording is created. Android shows its normal capture indicator and foreground notification while capture is active. The capture process still consumes battery/CPU, especially on low-memory devices. Stop the bot when not testing.

## Build

Android Gradle Plugin 8.13.2, Gradle 8.13, JDK 17, compileSdk 36. From this folder run `gradle --no-daemon clean assembleDebug`.
