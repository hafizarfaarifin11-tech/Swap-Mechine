# AI Controller v1.0.0 — Survival Controls (Offline/Sandbox)

Prototype Android overlay for testing mapped controls in an offline or self-owned sandbox game.

## What's new in v1.0.0

- **Held joystick gesture:** touches the joystick, drags to the selected direction, then continues the same accessibility stroke so the virtual finger stays down. This replaces the old short swipe-and-release movement.
- **Auto sprint:** sends one sprint tap after the user resumes the bot while a game app is in the foreground. The control may be a toggle in the target game.
- **Jumping:** AUTO and SURVIVAL can send periodic jump taps.
- **Camera control:** the camera anchor can be mapped and tested manually. When anti-stuck logic suspects a collision, it pans the camera and then tries a different joystick direction. Optional auto-camera mode makes small alternating camera sweeps every several seconds.
- **Crouch / heal / Gloo Wall mappings:** new points can be dragged in the layout editor.
- **Survival mode:** OCR checks visible HUD text for safe-zone and danger terms. It also estimates a colored health-bar fill from two calibrated points. An HP drop of roughly 4.5%, a low HP estimate, or danger text starts a sequence of four Gloo Wall taps with camera turns, then crouch and heal.
- **Foreground arming:** the bot starts paused. Open the offline game, tap the AI bubble, and choose RESUME BOT. This prevents accidental input while still on the AI Controller screen.

## Calibrate before running

1. Install the debug APK from a successful GitHub Actions run.
2. Grant overlay permission and enable **AI Controller Game Input** in Android Accessibility settings.
3. Open the game and tap the floating AI bubble, then choose **EDIT LAYOUT LANGSUNG DI GAME**.
4. Drag each labeled point to the exact center of its matching game control. The small toolbar can also be dragged away from the HUD.
5. Place **KAMERA** on a clear camera-drag region on the right side of the game view, not over a button or minimap.
6. Put **HP AWAL** and **HP AKHIR** on the left and right ends of the colored HP bar, both at its vertical center. The current detector recognizes red or green fill colors. If the game uses another color, HP estimation may be unavailable.
7. Tap **SIMPAN** and **SELESAI**, choose **SURVIVAL**, then tap **RESUME BOT** when ready.

## Behavior and limitations

- The anti-stuck system only compares coarse image changes. It does not understand a 3D map or identify a wall with certainty.
- Zone and danger recognition depend on HUD words being visible and readable by on-device OCR. It does not visually identify enemy characters.
- HP is an approximate color-fill estimate along the two mapped points. Poor calibration, animations, armor bars, or a differently colored bar can cause false readings.
- The defensive ring is an approximate series of four Gloo Wall taps while rotating the camera. Some games require a separate placement tap or a different button sequence; verify the control behavior in a safe offline test area.
- Sprint and crouch may be toggle controls in some games. Adjust the mapping and test them manually before enabling automation.
- No weapon aiming or firing automation is included. Use only in offline/self-owned test environments.

## Build

- Android Gradle Plugin 8.13.2
- Gradle 8.13
- JDK 17
- compileSdk 36
- ML Kit Text Recognition 16.0.1 (bundled)

Run `gradle --no-daemon clean assembleDebug` from this directory.


## In-game layout editor (v1.0.0)

Open the AI bubble while the game is visible, choose **EDIT LAYOUT LANGSUNG DI GAME**, then drag each small control marker onto the center of its matching in-game button. Save or finish from the small toolbar. Each marker is a separate overlay window: only the marker and toolbar areas receive touches, so empty screen areas continue to pass taps through to the game. Coordinates are stored from the marker's actual screen position (`getLocationOnScreen`) and normalized against the display's real pixel dimensions, matching the coordinates used by Accessibility gesture injection.
