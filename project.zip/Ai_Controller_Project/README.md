# AI Controller v0.3.0 — Bhop Pro Spotlight

Offline Android overlay coach focused on Bhop Pro.

## What's new in v0.3

- Adds a spotlight overlay that dims the screen and leaves a glowing circular cutout around the jump button.
- First use: open the bubble, choose **Tunjukkan Tombol Loncat**, tap or drag the circle to the game's jump button, then tap **Simpan Posisi**.
- Later uses reuse the saved position. Tap anywhere on the dimmed screen to close the spotlight and return to the bubble.
- Includes a reset/recalibration action in the overlay panel.
- Does not use MediaProjection, screen recording, screenshots, OCR, camera, microphone, network, or AI API keys.

## Important limitation

The app does not inspect Bhop Pro's screen, so it cannot automatically detect the jump button. The position is calibrated manually by the user and saved locally. The spotlight overlay temporarily receives the tap used to close it; tap the game button again after the overlay closes.

The spotlight is a visual guide only. It does not press or automate game controls.

## Build using the repository's `project.zip`

The archive contains the source directory `Ai_Controller_Project/`. Place the archive in the repository root with the exact name `project.zip`, then use the repository workflow at `.github/workflows/android.yml`. The workflow extracts the archive and builds the debug APK with Android SDK 36 and Gradle 8.13.

## Requirements

- Android 8.0 (API 26) or newer.
- Permission to display over other apps.
- Bhop Pro installed for the game launch shortcut.

## Local build

From this directory, run:

```bash
gradle --no-daemon clean assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
