# AI Controller — v0.1.0

Project repository: **Swap Mechine**  
APK app name: **AI Controller**

A lightweight Android floating assistant prototype. It captures a screen frame only after the user presses **Analyze Screen**, then runs bundled on-device ML Kit text recognition (OCR). A few local rules turn recognized words into basic hints.

## Included in v0.1

- Movable floating bubble and compact overlay panel.
- Android MediaProjection consent prompt before screen capture.
- User-triggered capture only; no continuous screenshot scanning.
- Bundled Latin text-recognition model; OCR runs locally without an API key.
- No Android `INTERNET` permission and no screenshot upload.
- Reduced image dimensions before OCR to limit memory pressure on a 4 GB RAM phone.

## Important limitations

This is **not** a full conversational AI or full game-vision model. It does not reliably identify enemies, players, weapons, health bars, minimap positions, or understand an entire gameplay scene. It reads visible text and applies simple offline rules. OCR can miss small, moving, low-contrast, stylized, or covered text. Some apps or games may block screen capture.

## Build with GitHub Actions

1. Extract `Ai_Controller_Project.zip` on your phone or computer.
2. Open the extracted `Ai_Controller_Project` folder.
3. Upload **the contents of that folder** to the root of your new GitHub repository named `Swap Mechine`. Do not upload the ZIP itself as the project source; GitHub does not automatically unpack ZIP files into source files.
4. Make sure the hidden path `.github/workflows/android.yml` is present in the repository. The same workflow text is also provided as `android.yml` at the project root for easy copying.
5. Commit to `main` (or `master`), then open the repository's **Actions** tab. You can also choose **Android CI → Run workflow**.
6. When the workflow succeeds, open the run and download the `Ai-Controller-debug-apk` artifact.

The CI uses Java 17, Gradle 8.13, Android Gradle Plugin 8.13.2, Android SDK 36, and `android-actions/setup-android@v4`. The setup action installs current command-line tools and platform-tools; the workflow explicitly installs platform 36 and build-tools 36.0.0. It does not request the retired SDK package named `tools`.

## First launch

1. Install the downloaded debug APK.
2. Open **AI Controller**.
3. Grant **Display over other apps** permission.
4. Tap **Mulai AI Assistant** and approve Android's screen-capture prompt.
5. Switch to a game, tap the floating **AI** bubble, then tap **Analyze Screen**.
6. Stop it from the app or the ongoing notification when finished.

## Privacy and network

The app does not declare the Android `INTERNET` permission. Screen frames are processed on-device by the bundled OCR library and are not sent to a server. The GitHub build itself requires internet access to download Gradle, Android SDK packages, and dependencies.
