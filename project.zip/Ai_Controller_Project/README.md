# AI Controller v0.8.0 — Auto Movement + Anti-Stuck Vision

Android prototype for user-controlled offline/sandbox game testing.

## Main fixes

- Default mode now sends joystick movement automatically instead of only reading HUD text.
- Movement commands are repeated with a longer gesture duration so the virtual joystick gets a more continuous directional input.
- The movement mode compares small, downsampled samples of the central game view. If the view barely changes across several samples while movement is being issued, the bot treats it as a possible stuck/collision state and tries a short alternative direction: reverse, diagonal-left, or diagonal-right.
- OCR is only used when the user explicitly selects the HUD text-reading mode, reducing unnecessary processing in movement mode.
- The seven-point HUD layout editor remains available for mapping the joystick and utility controls.

## Important limits

The anti-stuck feature is a visual heuristic, not a true wall detector or 3D navigation system. It cannot understand the map, identify an exact wall, or guarantee that an alternate direction is a valid route. It only notices that the visible scene is changing very little and tries a different joystick vector. Animated scenery, camera behavior, or static menus can cause false readings. Test in an offline/sandbox game and adjust the joystick position in the layout editor first.

The color-marker mode still follows a manually chosen high-saturation marker. OCR mode reads HUD text locally. There is no automatic weapon, aim, or fire control.

## Setup

1. Install the APK from the successful GitHub Actions debug artifact.
2. Allow Floating Overlay.
3. Enable **AI Controller Game Input** in Android Accessibility settings.
4. Open **Control Layout Editor** and drag the JOYSTICK label to the exact center of the game's movement joystick. Save the layout.
5. Return to the main screen and keep **AUTO: jalan + coba hindari saat stuck** selected.
6. Tap **SIMPAN PENGATURAN**, then **MULAI SCREEN READER + HUD** and approve screen capture.
7. Open the offline game. The AI bubble shows the current movement status.

If the bubble reports that Accessibility is inactive, return to Android Accessibility settings and enable the service. If the bot moves the wrong direction, correct the JOYSTICK mapping in the editor; the preset position is only a fallback.

## Build

- Android Gradle Plugin 8.13.2
- Gradle 8.13
- JDK 17
- compileSdk 36
- ML Kit Text Recognition 16.0.1 (bundled)

Run `gradle --no-daemon clean assembleDebug` from this directory.
