# AI Controller v0.7.0 — HUD Layout + Offline Screen Reader

Android prototype for a user-controlled offline/sandbox game test.

## What's fixed from v0.6

- Added a visual drag-and-drop control layout editor; no more typing screen percentages by hand.
- Editable markers: movement joystick, jump, sprint, crouch, prone, interact, and heal.
- Added a visible, non-touchable HUD marker overlay while the screen reader is active.
- Added bundled ML Kit Text Recognition so OCR is processed locally without an API key or model download at runtime.
- Added a local rule engine that displays recognized HUD text and limited recommendations.
- Capture samples the screen periodically at a maximum 640px long edge; frames are processed in memory and not saved as a video.
- AccessibilityService dispatches only mapped movement / utility controls. No automatic weapon, aim, or fire controls are included.

## What the local AI can and cannot do

The OCR can read visible text, counters, and prompts if they are large and clear enough. Rules can recognize a few phrases (zone warnings, revive/open/pickup/interact prompts, danger warnings, cover prompts, and low-health prompts) and suggest or tap mapped sprint/interact/crouch/prone/heal controls when automatic HUD actions are enabled. This is a lightweight offline rule engine, not a model trained to understand the full game scene. It does not identify opponents, terrain, safe routes, or all on-screen objects. If the game HUD is icon-only, OCR may return little or no text.

## Setup

1. Install the APK produced by GitHub Actions.
2. Allow Floating Overlay.
3. Enable **AI Controller Game Input** in Android Accessibility settings. This is required to dispatch taps and swipes.
4. Open **Control Layout Editor**. Drag the seven labels to match the game's on-screen controls, then tap Save.
5. Return to the main screen. Choose **Baca teks HUD + saran lokal** to start with OCR rules.
6. Leave automatic HUD actions off for the first test. Turn them on only after checking that the detected text and suggestions are correct.
7. Tap Start and approve the Android screen-capture prompt. Android displays its normal capture indicator and foreground notification.
8. Open the game. Tap the AI bubble to view recognized HUD text, decision status, pause/resume, HUD markers, or stop.

## Notes

- The layout editor stores normalized screen percentages. Place controls while the phone is in landscape and keep the game's HUD layout/scale unchanged.
- The overlay markers are visual guides and do not intercept game touches.
- Screen capture must be approved for each new MediaProjection session on Android 14+.
- Capture interval defaults to a slow setting to reduce load on devices with 4 GB RAM.
- No API key is used. ML Kit text recognition is bundled into the APK, and this app does not upload captured frames.

## Build

- Android Gradle Plugin 8.13.2
- Gradle 8.13
- JDK 17
- compileSdk 36
- ML Kit Text Recognition 16.0.1 (bundled)

From this directory: `gradle --no-daemon clean assembleDebug`.
