# AI Controller — v0.2.0 (Bhop Pro Coach)

Repository target: **Swap Mechine**  
APK label: **AI Controller**  
Profile in this release: **Bhop Pro**

## What changed from v0.1

- Removed Android MediaProjection completely.
- Removed screen capture, VirtualDisplay, ImageReader, and OCR dependencies.
- Removed the ML Kit dependency and all network permissions/libraries.
- The floating overlay is now a manual, context-based Bhop Pro practice coach.
- Added an optional button to launch the installed Bhop Pro app (`com.begma.bhoppro`).
- Updated app version to 0.2.0 / versionCode 2.

## How the coach works

The app does not inspect Bhop Pro's screen, read game state, press controls, or record anything. The player taps the floating **B** bubble and selects a condition such as:

- Basic bunny hop
- Speed not increasing
- Practice a left or right turn
- Losing control
- Approaching a landing
- Touch-control setup
- Short practice routine

The app then displays prewritten offline guidance for that context. It is a lightweight rule-based coach, **not a self-learning or generative AI model**. It cannot detect what is happening in the game automatically because screen access has been intentionally removed.

The Bhop Pro tips are based on the game's public description: bunny hopping uses air-strafing to gain speed, and the game describes turning left or right while synchronizing with jumping. Sources: Google Play listing for `bhop pro` by begma.

## Privacy and performance

- No `MediaProjection` API or screen recording.
- No OCR, screenshot processing, or image model.
- No `INTERNET` permission.
- No API key, server, or bundled AI model.
- Only a small foreground service is used to keep the floating overlay visible; Android shows its normal ongoing notification.
- The assistant does not automate touch input or control the game.

## Build with the `project.zip` workflow

1. Rename this ZIP file to **`project.zip`** before uploading it to the `Swap Mechine` repository root.
2. In the repository, create `.github/workflows/android.yml`.
3. Copy the contents of the `android.yml` file from this project into that workflow file. This workflow checks and extracts `project.zip`, then builds the APK.
4. Commit the workflow and `project.zip` to `main`.
5. Open **Actions** and download artifact `Ai-Controller-BhopPro-v0.2-debug` after a successful run.

If you instead extract this archive and upload the project contents directly to the repository root, the included `.github/workflows/android.yml` performs a direct build. Do not use both workflow approaches at once unless you want two builds.

## Permissions

The app needs **Display over other apps** permission for its floating bubble. It uses a `specialUse` foreground service to keep that bubble visible while you switch to Bhop Pro. It does not request screen capture permission.
